
-- Add heart rate columns to workouts table
ALTER TABLE public.workouts ADD COLUMN heart_rate_image text;
ALTER TABLE public.workouts ADD COLUMN heart_rate_analysis jsonb;

-- Create workout-images storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('workout-images', 'workout-images', true);

-- RLS: only owning user can upload
CREATE POLICY "Users can upload own workout images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'workout-images' AND (storage.foldername(name))[1] = auth.uid()::text);

-- RLS: only owning user can view
CREATE POLICY "Users can view own workout images"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'workout-images' AND (storage.foldername(name))[1] = auth.uid()::text);

-- RLS: only owning user can update
CREATE POLICY "Users can update own workout images"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'workout-images' AND (storage.foldername(name))[1] = auth.uid()::text);

-- RLS: only owning user can delete
CREATE POLICY "Users can delete own workout images"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'workout-images' AND (storage.foldername(name))[1] = auth.uid()::text);
