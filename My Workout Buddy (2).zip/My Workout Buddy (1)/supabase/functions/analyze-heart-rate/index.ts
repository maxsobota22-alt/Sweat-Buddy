import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { imageUrl, workoutSummary } = await req.json();
    if (!imageUrl) {
      return new Response(JSON.stringify({ error: "imageUrl is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are a fitness heart rate analyst. You will receive a screenshot of heart rate data from a workout (typically from an Oura ring or similar device). Extract the following information and return it using the analyze_heart_rate tool. If you cannot determine a value from the image, make your best estimate based on what's visible. The workout context is: ${workoutSummary || "a strength training workout"}.`,
          },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: { url: imageUrl },
              },
              {
                type: "text",
                text: "Analyze this heart rate data from my workout. Extract peak HR, average HR, intensity level, any visible HR zone information, and provide a brief summary of the cardiovascular effort.",
              },
            ],
          },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "analyze_heart_rate",
              description: "Return structured heart rate analysis from the screenshot",
              parameters: {
                type: "object",
                properties: {
                  peak_hr: { type: "number", description: "Peak heart rate observed" },
                  avg_hr: { type: "number", description: "Average heart rate during the workout" },
                  intensity: {
                    type: "string",
                    enum: ["low", "moderate", "high", "very_high"],
                    description: "Overall workout intensity based on HR data",
                  },
                  zones: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        zone: { type: "string", description: "Zone name (e.g. Zone 1, Fat Burn, Cardio)" },
                        minutes: { type: "number", description: "Minutes spent in this zone" },
                      },
                      required: ["zone", "minutes"],
                    },
                    description: "Time spent in each HR zone if visible",
                  },
                  summary: {
                    type: "string",
                    description: "Brief 2-3 sentence summary of the cardiovascular effort and any notable patterns",
                  },
                },
                required: ["peak_hr", "avg_hr", "intensity", "summary"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "analyze_heart_rate" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded, please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI analysis failed" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = await response.json();
    const toolCall = result.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      return new Response(JSON.stringify({ error: "AI did not return structured data" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const analysis = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(analysis), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-heart-rate error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
