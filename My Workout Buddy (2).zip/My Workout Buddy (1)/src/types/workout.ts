export interface WorkoutSet {
  id: string;
  reps: number;
  weight: number;
  completed: boolean;
}

export interface Exercise {
  id: string;
  name: string;
  primaryMuscle?: string;
  sets: WorkoutSet[];
  notes?: string;
}

export interface HeartRateAnalysis {
  peak_hr: number;
  avg_hr: number;
  intensity: 'low' | 'moderate' | 'high' | 'very_high';
  zones?: { zone: string; minutes: number }[];
  summary: string;
}

export interface Workout {
  id: string;
  name: string;
  date: string; // ISO string
  duration: number; // minutes
  exercises: Exercise[];
  completed: boolean;
  heart_rate_image?: string;
  heart_rate_analysis?: HeartRateAnalysis;
}

export interface ExerciseHistory {
  date: string;
  maxWeight: number;
  totalVolume: number;
  totalSets: number;
  totalReps: number;
}
