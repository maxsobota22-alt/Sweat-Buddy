import { useState, useCallback } from 'react';

export type WeightUnit = 'lbs' | 'kg';

const STORAGE_KEY = 'weight-unit';
const KG_FACTOR = 0.453592; // 1 lb in kg

function getStoredUnit(): WeightUnit {
  const stored = localStorage.getItem(STORAGE_KEY);
  return stored === 'kg' ? 'kg' : 'lbs';
}

// Module-level singleton so all consumers share state without a context provider.
// Re-renders are triggered by calling setUnit which calls all registered listeners.
let currentUnit: WeightUnit = getStoredUnit();
const listeners = new Set<() => void>();

function notifyAll() {
  listeners.forEach(fn => fn());
}

export function useWeightUnit() {
  const [, forceUpdate] = useState(0);

  // Register this component as a listener
  useState(() => {
    const fn = () => forceUpdate(n => n + 1);
    listeners.add(fn);
    return () => listeners.delete(fn);
  });

  const setUnit = useCallback((unit: WeightUnit) => {
    currentUnit = unit;
    localStorage.setItem(STORAGE_KEY, unit);
    notifyAll();
  }, []);

  const toDisplay = useCallback((lbs: number): number => {
    if (currentUnit === 'kg') return Math.round(lbs * KG_FACTOR * 10) / 10;
    return lbs;
  }, [currentUnit]);

  const fromDisplay = useCallback((value: number): number => {
    if (currentUnit === 'kg') return Math.round(value / KG_FACTOR * 10) / 10;
    return value;
  }, [currentUnit]);

  return {
    unit: currentUnit,
    setUnit,
    toDisplay,
    fromDisplay,
    label: currentUnit,
  };
}
