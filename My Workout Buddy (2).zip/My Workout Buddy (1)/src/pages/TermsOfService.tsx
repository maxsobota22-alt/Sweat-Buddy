import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export default function TermsOfService() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="px-5 pt-6 max-w-2xl mx-auto">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted-foreground mb-6 hover:text-foreground">
          <ChevronLeft className="w-5 h-5" /> Back
        </button>

        <h1 className="text-2xl font-heading font-bold mb-2">Terms of Service</h1>
        <p className="text-muted-foreground text-sm mb-8">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

        <div className="space-y-6 text-sm text-foreground/90 leading-relaxed">

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">1. Acceptance of Terms</h2>
            <p>
              By creating an account and using Sweat Buddy, you agree to be bound by these Terms of Service. If you do not agree, please do not use the application.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">2. Medical Disclaimer</h2>
            <p className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 text-foreground">
              <strong>Important:</strong> Sweat Buddy is a personal fitness tracking tool, not a medical device or medical service. The information and data within this app are for informational and tracking purposes only. Always consult a qualified healthcare professional before beginning any new exercise program, especially if you have a pre-existing medical condition, injury, or health concern. We are not responsible for any injury or harm that may result from following workouts logged in this app.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">3. Eligibility</h2>
            <p>
              You must be at least 13 years of age to use Sweat Buddy. By using the service, you represent that you meet this requirement.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">4. Your Account</h2>
            <ul className="list-disc ml-5 space-y-1">
              <li>You are responsible for maintaining the confidentiality of your account credentials.</li>
              <li>You are responsible for all activity that occurs under your account.</li>
              <li>You must provide a valid email address to create an account.</li>
              <li>You may delete your account and all associated data at any time from Settings.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">5. Acceptable Use</h2>
            <p className="mb-2">You agree not to:</p>
            <ul className="list-disc ml-5 space-y-1">
              <li>Use the service for any unlawful purpose.</li>
              <li>Attempt to gain unauthorised access to other users' data.</li>
              <li>Interfere with or disrupt the service or its infrastructure.</li>
              <li>Upload malicious files or content.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">6. Your Data</h2>
            <p>
              You own your workout data. We process it only as described in our Privacy Policy to provide the service to you. You can export or delete your data at any time.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">7. Service Availability</h2>
            <p>
              We strive to keep Sweat Buddy available at all times, but we do not guarantee uninterrupted access. We reserve the right to modify, suspend, or discontinue the service with reasonable notice.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">8. Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by law, Sweat Buddy and its operators shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of the service, including but not limited to physical injury, data loss, or loss of profits.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">9. Changes to These Terms</h2>
            <p>
              We may update these Terms from time to time. Continued use of the service after changes constitutes acceptance of the revised Terms.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">10. Contact</h2>
            <p>
              For questions about these Terms, please contact us through the app.
            </p>
          </section>

        </div>
      </div>
    </div>
  );
}
