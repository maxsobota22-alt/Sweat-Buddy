import { useState } from 'react';
import { useWorkouts } from '@/hooks/useWorkouts';
import { useExerciseLibrary, MUSCLE_GROUPS } from '@/hooks/useExerciseLibrary';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { format } from 'date-fns';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const WORKOUT_COUNT_OPTIONS = [3, 4, 5, 6, 7, 10, 15, 20];

export default function Progress() {
  const { getUniqueExercises, getExerciseHistory, workouts } = useWorkouts();
  const { getExerciseMuscle, exercises: libraryExercises, isUnilateral } = useExerciseLibrary();
  const exercises = getUniqueExercises();
  const [selected, setSelected] = useState(exercises[0] || '');
  const history = selected ? getExerciseHistory(selected) : [];

  const [volumeCount, setVolumeCount] = useState(7);
  const [setsCount, setSetsCount] = useState(7);
  const [prDays, setPrDays] = useState(30);

  const weeklyVolume = getWeeklyVolume(workouts, isUnilateral);
  const volumeStats = getMuscleStats(workouts, getExerciseMuscle, isUnilateral, volumeCount);
  const setsStats = getMuscleStats(workouts, getExerciseMuscle, isUnilateral, setsCount);
  const prStats = getPRStatsByMuscle(libraryExercises, prDays);

  return (
    <div className="min-h-screen bg-background pb-24 pt-safe">
      <div className="px-5 pt-8 max-w-lg mx-auto">
        <h1 className="text-2xl font-heading font-bold mb-6">Progress</h1>

        {/* Volume by Muscle */}
        <div className="bg-card rounded-xl p-4 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-muted-foreground">VOLUME BY MUSCLE (LBS)</h2>
            <WorkoutCountFilter value={volumeCount} onChange={setVolumeCount} />
          </div>
          <ResponsiveContainer width="100%" height={Math.max(200, volumeStats.length * 24)}>
            <BarChart data={volumeStats} layout="vertical">
              <XAxis type="number" tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="muscle" tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} width={80} />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="volume" fill="hsl(72 100% 50%)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Sets by Muscle */}
        <div className="bg-card rounded-xl p-4 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-muted-foreground">SETS BY MUSCLE</h2>
            <WorkoutCountFilter value={setsCount} onChange={setSetsCount} />
          </div>
          <div className="space-y-2">
            {setsStats.map(m => {
              const maxSets = Math.max(...setsStats.map(x => x.sets), 1);
              return (
                <div key={m.muscle} className="flex items-center justify-between">
                  <span className="text-sm text-foreground">{m.muscle}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${Math.min(100, (m.sets / maxSets) * 100)}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground w-8 text-right">{m.sets}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* PRs by Muscle */}
        <div className="bg-card rounded-xl p-4 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-muted-foreground">PRs BY MUSCLE</h2>
            <DaysFilter value={prDays} onChange={setPrDays} />
          </div>
          <ResponsiveContainer width="100%" height={Math.max(200, prStats.length * 24)}>
            <BarChart data={prStats} layout="vertical">
              <XAxis type="number" allowDecimals={false} tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="muscle" tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} width={80} />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="count" name="PRs" fill="hsl(340 80% 55%)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Weekly Volume Chart */}
        <div className="bg-card rounded-xl p-4 mb-6">
          <h2 className="text-sm font-semibold mb-3 text-muted-foreground">WEEKLY VOLUME (LBS)</h2>
          {weeklyVolume.length < 2 ? (
            <p className="text-muted-foreground text-sm text-center py-8">Complete more workouts to see trends</p>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={weeklyVolume}>
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} width={40} />
                <Tooltip contentStyle={tooltipStyle} />
                <Line type="monotone" dataKey="volume" stroke="hsl(72 100% 50%)" strokeWidth={2} dot={{ fill: 'hsl(72 100% 50%)', r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Exercise Progress */}
        <div className="bg-card rounded-xl p-4">
          <h2 className="text-sm font-semibold mb-3 text-muted-foreground">EXERCISE PROGRESS</h2>
          {exercises.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-8">No exercises logged yet</p>
          ) : (
            <>
              <div className="flex gap-2 flex-wrap mb-4">
                {exercises.map(e => (
                  <button
                    key={e}
                    onClick={() => setSelected(e)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      selected === e ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
              {history.length < 2 ? (
                <p className="text-muted-foreground text-sm text-center py-6">Need at least 2 sessions to show progress</p>
              ) : (
                <ResponsiveContainer width="100%" height={180}>
                  <LineChart data={history.map(h => ({ ...h, date: format(new Date(h.date), 'M/d') }))}>
                    <XAxis dataKey="date" tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: 'hsl(220 8% 55%)' }} axisLine={false} tickLine={false} width={40} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Line type="monotone" dataKey="maxWeight" name="Max Weight" stroke="hsl(72 100% 50%)" strokeWidth={2} dot={{ fill: 'hsl(72 100% 50%)', r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

const tooltipStyle = {
  background: 'hsl(220 13% 12%)',
  border: '1px solid hsl(220 10% 20%)',
  borderRadius: '8px',
  fontSize: '12px',
  color: 'hsl(0 0% 95%)',
};

function WorkoutCountFilter({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <Select value={String(value)} onValueChange={v => onChange(Number(v))}>
      <SelectTrigger className="w-auto h-7 text-xs bg-secondary border-border gap-1 px-2">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {WORKOUT_COUNT_OPTIONS.map(n => (
          <SelectItem key={n} value={String(n)}>Last {n} workouts</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function DaysFilter({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <Select value={String(value)} onValueChange={v => onChange(Number(v))}>
      <SelectTrigger className="w-auto h-7 text-xs bg-secondary border-border gap-1 px-2">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {[7, 14, 30, 60, 90].map(n => (
          <SelectItem key={n} value={String(n)}>Last {n} days</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function getWeeklyVolume(workouts: any[], isUnilateral: (name: string) => boolean) {
  const completed = workouts.filter(w => w.completed);
  const weekMap = new Map<string, number>();
  completed.forEach(w => {
    const d = new Date(w.date);
    const weekStart = new Date(d);
    weekStart.setDate(d.getDate() - d.getDay());
    const key = format(weekStart, 'M/d');
    const vol = w.exercises.reduce((s: number, e: any) => {
      const mult = isUnilateral(e.name) ? 2 : 1;
      return s + e.sets.reduce((ss: number, set: any) => ss + set.reps * set.weight * mult, 0);
    }, 0);
    weekMap.set(key, (weekMap.get(key) || 0) + vol);
  });
  return Array.from(weekMap.entries()).map(([label, volume]) => ({ label, volume }));
}

function getMuscleStats(workouts: any[], getExerciseMuscle: (name: string) => string | undefined, isUnilateral: (name: string) => boolean, count: number) {
  const completed = workouts
    .filter(w => w.completed)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, count);

  const stats = new Map<string, { volume: number; sets: number }>();
  MUSCLE_GROUPS.forEach(mg => stats.set(mg, { volume: 0, sets: 0 }));

  completed.forEach(w => {
    w.exercises.forEach((e: any) => {
      const muscle = e.primaryMuscle || getExerciseMuscle(e.name) || 'Other';
      const existing = stats.get(muscle) || { volume: 0, sets: 0 };
      const mult = isUnilateral(e.name) ? 2 : 1;
      const vol = e.sets.reduce((s: number, set: any) => s + set.reps * set.weight * mult, 0);
      existing.volume += vol;
      existing.sets += e.sets.length;
      stats.set(muscle, existing);
    });
  });

  return Array.from(stats.entries())
    .filter(([muscle]) => MUSCLE_GROUPS.includes(muscle as any))
    .map(([muscle, data]) => ({ muscle, ...data }))
    .sort((a, b) => b.volume - a.volume);
}

function getPRStatsByMuscle(libraryExercises: any[], days: number) {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);

  const counts = new Map<string, number>();
  MUSCLE_GROUPS.forEach(mg => counts.set(mg, 0));

  libraryExercises.forEach(ex => {
    (ex.prs || []).forEach((pr: any) => {
      if (new Date(pr.date) >= cutoff) {
        counts.set(ex.primaryMuscle, (counts.get(ex.primaryMuscle) || 0) + 1);
      }
    });
  });

  return Array.from(counts.entries())
    .map(([muscle, count]) => ({ muscle, count }))
    .sort((a, b) => b.count - a.count);
}
