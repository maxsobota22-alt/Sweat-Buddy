import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export default function PrivacyPolicy() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background pb-16">
      <div className="px-5 pt-6 max-w-2xl mx-auto">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted-foreground mb-6 hover:text-foreground">
          <ChevronLeft className="w-5 h-5" /> Back
        </button>

        <h1 className="text-2xl font-heading font-bold mb-2">Privacy Policy</h1>
        <p className="text-muted-foreground text-sm mb-8">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>

        <div className="prose prose-invert max-w-none space-y-6 text-sm text-foreground/90 leading-relaxed">

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">1. Who We Are</h2>
            <p>
              Sweat Buddy ("we", "us", "our") is a personal workout tracking application. We are committed to protecting your privacy and handling your data responsibly.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">2. Data We Collect</h2>
            <p className="mb-2">When you use Sweat Buddy, we collect the following information:</p>
            <ul className="list-disc ml-5 space-y-1">
              <li><strong>Account information:</strong> email address and encrypted password (used for authentication only).</li>
              <li><strong>Workout data:</strong> workout names, dates, duration, exercises, sets, reps, and weights you log.</li>
              <li><strong>Body metrics:</strong> body weight values you voluntarily enter.</li>
              <li><strong>Health &amp; fitness data:</strong> heart rate screenshots and AI-analysed heart rate metrics you optionally upload.</li>
              <li><strong>Usage data:</strong> basic application usage patterns for improving the service.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">3. How We Use Your Data</h2>
            <ul className="list-disc ml-5 space-y-1">
              <li>To provide and maintain the workout tracking service.</li>
              <li>To calculate personal records, volume statistics, and progress analytics shown to you.</li>
              <li>To sync your data across devices when you are signed in.</li>
              <li>We do <strong>not</strong> sell your data to third parties.</li>
              <li>We do <strong>not</strong> use your data for advertising.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">4. Data Storage &amp; Security</h2>
            <p>
              Your data is stored securely using <a href="https://supabase.com" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">Supabase</a> (PostgreSQL database with row-level security). Heart rate images are stored in Supabase object storage. All data is stored in the United States. We use encryption in transit (HTTPS/TLS) for all communications.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">5. Your Rights (GDPR / CCPA)</h2>
            <p className="mb-2">You have the right to:</p>
            <ul className="list-disc ml-5 space-y-1">
              <li><strong>Access</strong> your data: export all your workout data in JSON format from Settings.</li>
              <li><strong>Delete</strong> your data: permanently delete your account and all associated data from Settings → Delete Account.</li>
              <li><strong>Portability:</strong> download your data at any time from Settings.</li>
              <li><strong>Correction:</strong> edit any data directly within the app.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">6. Cookies &amp; Local Storage</h2>
            <p>
              We use browser localStorage to store your active workout timer and display preferences (e.g., weight unit). No third-party tracking cookies are used.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">7. Children's Privacy</h2>
            <p>
              Sweat Buddy is not directed at children under 13 years of age. We do not knowingly collect personal information from children under 13.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">8. Changes to This Policy</h2>
            <p>
              We may update this privacy policy from time to time. We will notify you of material changes by posting the new policy with an updated date.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">9. Contact</h2>
            <p>
              If you have questions about this Privacy Policy or wish to exercise your data rights, please contact us through the app.
            </p>
          </section>

        </div>
      </div>
    </div>
  );
}
