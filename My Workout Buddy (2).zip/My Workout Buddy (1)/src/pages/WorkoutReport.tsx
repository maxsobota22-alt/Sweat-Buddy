import { useParams, useNavigate } from 'react-router-dom';
import { useWorkouts } from '@/hooks/useWorkouts';
import { useExerciseLibrary } from '@/hooks/useExerciseLibrary';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Trophy, TrendingUp, TrendingDown, Star, ArrowRight, Heart, Upload, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useState, useRef } from 'react';
import { toast } from 'sonner';
import type { Exercise, HeartRateAnalysis } from '@/types/workout';

interface ExerciseComparison {
  name: string;
  isFirstTime: boolean;
  currentVolume: number;
  previousVolume?: number;
  volumeChange?: number;
  currentMaxWeight: number;
  previousMaxWeight?: number;
  currentSets: number;
  previousSets?: number;
  currentReps: number;
  previousReps?: number;
  newPRs: { reps: number; weight: number; previousWeight?: number }[];
}

function computeExerciseVolume(exercise: Exercise, isUnilateral: boolean): number {
  const multiplier = isUnilateral ? 2 : 1;
  return exercise.sets
    .filter(s => s.completed)
    .reduce((sum, s) => sum + s.reps * s.weight * multiplier, 0);
}

const intensityColors: Record<string, string> = {
  low: 'bg-green-500/20 text-green-400',
  moderate: 'bg-yellow-500/20 text-yellow-400',
  high: 'bg-orange-500/20 text-orange-400',
  very_high: 'bg-red-500/20 text-red-400',
};

const intensityLabels: Record<string, string> = {
  low: 'Low',
  moderate: 'Moderate',
  high: 'High',
  very_high: 'Very High',
};

export default function WorkoutReport() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { workouts, updateWorkout } = useWorkouts();
  const { exercises: libraryExercises } = useExerciseLibrary();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);

  const workout = workouts.find(w => w.id === id);

  if (!workout) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Workout not found</p>
      </div>
    );
  }

  const completedWorkouts = workouts.filter(w => w.completed && w.id !== id);

  const comparisons: ExerciseComparison[] = workout.exercises.map(exercise => {
    const libEx = libraryExercises.find(e => e.name === exercise.name);
    const isUnilateral = libEx?.unilateral ?? false;

    const previousWorkout = completedWorkouts
      .filter(w => w.exercises.some(e => e.name === exercise.name))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

    const previousExercise = previousWorkout?.exercises.find(e => e.name === exercise.name);

    const currentVolume = computeExerciseVolume(exercise, isUnilateral);
    const currentCompletedSets = exercise.sets.filter(s => s.completed);
    const currentMaxWeight = currentCompletedSets.length > 0
      ? Math.max(...currentCompletedSets.map(s => s.weight))
      : 0;
    const currentReps = currentCompletedSets.reduce((sum, s) => sum + s.reps, 0);

    if (!previousExercise) {
      return {
        name: exercise.name,
        isFirstTime: true,
        currentVolume,
        currentMaxWeight,
        currentSets: currentCompletedSets.length,
        currentReps,
        newPRs: [],
      };
    }

    const previousVolume = computeExerciseVolume(previousExercise, isUnilateral);
    const prevCompletedSets = previousExercise.sets.filter(s => s.completed);
    const previousMaxWeight = prevCompletedSets.length > 0
      ? Math.max(...prevCompletedSets.map(s => s.weight))
      : 0;
    const previousReps = prevCompletedSets.reduce((sum, s) => sum + s.reps, 0);
    const volumeChange = previousVolume > 0
      ? ((currentVolume - previousVolume) / previousVolume) * 100
      : 0;

    const newPRs: ExerciseComparison['newPRs'] = [];
    if (libEx) {
      const prevBestByReps = new Map<number, number>();
      prevCompletedSets.forEach(s => {
        const existing = prevBestByReps.get(s.reps) ?? 0;
        if (s.weight > existing) prevBestByReps.set(s.reps, s.weight);
      });

      currentCompletedSets.forEach(s => {
        const pr = libEx.prs.find(p => p.reps === s.reps);
        if (pr && pr.weight === s.weight) {
          const prevWeight = prevBestByReps.get(s.reps);
          if (prevWeight === undefined || s.weight > prevWeight) {
            if (!newPRs.some(p => p.reps === s.reps)) {
              newPRs.push({ reps: s.reps, weight: s.weight, previousWeight: prevWeight });
            }
          }
        }
      });
    }

    return {
      name: exercise.name,
      isFirstTime: false,
      currentVolume,
      previousVolume,
      volumeChange,
      currentMaxWeight,
      previousMaxWeight,
      currentSets: currentCompletedSets.length,
      previousSets: prevCompletedSets.length,
      currentReps,
      previousReps,
      newPRs,
    };
  });

  const totalNewPRs = comparisons.reduce((sum, c) => sum + c.newPRs.length, 0);

  const handleUploadHR = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user || !workout) return;

    setUploading(true);
    try {
      const filePath = `${user.id}/${workout.id}.${file.name.split('.').pop()}`;
      const { error: uploadError } = await supabase.storage
        .from('workout-images')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('workout-images')
        .getPublicUrl(filePath);

      const imageUrl = urlData.publicUrl;
      updateWorkout(workout.id, { heart_rate_image: imageUrl });

      // Now analyze
      setUploading(false);
      setAnalyzing(true);

      const workoutSummary = `${workout.name}, ${workout.duration} min, ${workout.exercises.length} exercises`;
      const { data: analysis, error: fnError } = await supabase.functions.invoke('analyze-heart-rate', {
        body: { imageUrl, workoutSummary },
      });

      if (fnError) throw fnError;

      updateWorkout(workout.id, { heart_rate_analysis: analysis });
      toast.success('Heart rate data analyzed!');
    } catch (err: any) {
      console.error('HR upload/analysis error:', err);
      toast.error(err.message || 'Failed to upload/analyze heart rate data');
    } finally {
      setUploading(false);
      setAnalyzing(false);
    }
  };

  const hrAnalysis = workout.heart_rate_analysis as HeartRateAnalysis | undefined;

  return (
    <div className="min-h-screen bg-background pb-24 pt-safe">
      <div className="px-5 pt-4 max-w-lg mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="font-heading font-bold text-xl mb-1">Workout Report</h1>
          <p className="text-muted-foreground text-sm">
            {workout.name} — {workout.duration} min
          </p>
          {totalNewPRs > 0 && (
            <div className="mt-3 inline-flex items-center gap-1.5 bg-primary/10 text-primary px-3 py-1.5 rounded-full text-sm font-semibold">
              <Trophy className="w-4 h-4" />
              {totalNewPRs} New PR{totalNewPRs > 1 ? 's' : ''}!
            </div>
          )}
        </div>

        {/* Exercise Cards */}
        <div className="space-y-3">
          {comparisons.map((comp, i) => (
            <div key={i} className="bg-card rounded-xl p-4 animate-slide-up">
              <h3 className="text-primary font-semibold text-sm mb-3">{comp.name}</h3>

              {comp.isFirstTime ? (
                <div className="flex items-center gap-2 text-muted-foreground text-sm">
                  <Star className="w-4 h-4 text-primary" />
                  First time — no comparison available
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Volume</span>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{comp.currentVolume.toLocaleString()} lbs</span>
                      {comp.volumeChange !== undefined && comp.volumeChange !== 0 && (
                        <span className={`flex items-center gap-0.5 text-xs font-medium ${
                          comp.volumeChange > 0 ? 'text-green-500' : 'text-red-500'
                        }`}>
                          {comp.volumeChange > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                          {Math.abs(comp.volumeChange).toFixed(0)}%
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Max Weight</span>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{comp.currentMaxWeight} lbs</span>
                      {comp.previousMaxWeight !== undefined && comp.previousMaxWeight !== comp.currentMaxWeight && (
                        <span className="text-xs text-muted-foreground">was {comp.previousMaxWeight}</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Sets</span>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{comp.currentSets}</span>
                      {comp.previousSets !== undefined && comp.previousSets !== comp.currentSets && (
                        <span className="text-xs text-muted-foreground">was {comp.previousSets}</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Total Reps</span>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{comp.currentReps}</span>
                      {comp.previousReps !== undefined && comp.previousReps !== comp.currentReps && (
                        <span className="text-xs text-muted-foreground">was {comp.previousReps}</span>
                      )}
                    </div>
                  </div>

                  {comp.newPRs.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-border space-y-1">
                      {comp.newPRs.map((pr, j) => (
                        <div key={j} className="flex items-center gap-2 text-sm">
                          <Trophy className="w-3.5 h-3.5 text-primary" />
                          <span className="font-semibold text-primary">
                            NEW PR: {pr.reps} reps @ {pr.weight} lbs
                          </span>
                          {pr.previousWeight !== undefined && (
                            <span className="text-xs text-muted-foreground">was {pr.previousWeight} lbs</span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Heart Rate Section */}
        <div className="mt-6">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleUploadHR}
          />

          {hrAnalysis ? (
            <div className="bg-card rounded-xl p-4 animate-slide-up">
              <div className="flex items-center gap-2 mb-3">
                <Heart className="w-4 h-4 text-red-500" />
                <h3 className="font-semibold text-sm">Heart Rate Analysis</h3>
                <span className={`ml-auto text-xs font-medium px-2 py-0.5 rounded-full ${intensityColors[hrAnalysis.intensity] || ''}`}>
                  {intensityLabels[hrAnalysis.intensity] || hrAnalysis.intensity} Intensity
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="bg-background rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-red-500">{hrAnalysis.peak_hr}</p>
                  <p className="text-xs text-muted-foreground">Peak HR</p>
                </div>
                <div className="bg-background rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-primary">{hrAnalysis.avg_hr}</p>
                  <p className="text-xs text-muted-foreground">Avg HR</p>
                </div>
              </div>

              {hrAnalysis.zones && hrAnalysis.zones.length > 0 && (
                <div className="mb-3 space-y-1">
                  <p className="text-xs font-medium text-muted-foreground mb-1">HR Zones</p>
                  {hrAnalysis.zones.map((z, i) => (
                    <div key={i} className="flex justify-between text-xs">
                      <span className="text-foreground/80">{z.zone}</span>
                      <span className="text-muted-foreground">{z.minutes} min</span>
                    </div>
                  ))}
                </div>
              )}

              <p className="text-sm text-muted-foreground">{hrAnalysis.summary}</p>

              {workout.heart_rate_image && (
                <img
                  src={workout.heart_rate_image}
                  alt="Heart rate data"
                  className="mt-3 rounded-lg w-full max-h-48 object-contain bg-background"
                />
              )}

              <button
                onClick={() => fileInputRef.current?.click()}
                className="mt-2 text-xs text-muted-foreground hover:text-primary transition-colors"
              >
                Replace screenshot
              </button>
            </div>
          ) : (
            <Button
              variant="outline"
              className="w-full"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading || analyzing}
            >
              {uploading ? (
                <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Uploading...</>
              ) : analyzing ? (
                <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Analyzing heart rate...</>
              ) : (
                <><Upload className="w-4 h-4 mr-2" /> Add Heart Rate Screenshot</>
              )}
            </Button>
          )}
        </div>

        {/* Done Button */}
        <Button
          onClick={() => navigate('/workout')}
          className="w-full mt-4 h-12 font-semibold"
        >
          Done
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
