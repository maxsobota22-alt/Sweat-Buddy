import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useWorkouts } from '@/hooks/useWorkouts';
import { useExerciseLibrary } from '@/hooks/useExerciseLibrary';
import { useBodyWeight } from '@/hooks/useBodyWeight';
import { useWeightUnit } from '@/hooks/useWeightUnit';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { ChevronLeft, Download, LogOut, Trash2, Shield, FileText, Moon, Sun } from 'lucide-react';
import { toast } from 'sonner';

export default function Settings() {
  const { user, signOut } = useAuth();
  const { workouts } = useWorkouts();
  const { exercises } = useExerciseLibrary();
  const { bodyWeight } = useBodyWeight();
  const { unit, setUnit } = useWeightUnit();
  const navigate = useNavigate();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [darkMode, setDarkMode] = useState(() => document.documentElement.classList.contains('dark'));

  const toggleDarkMode = () => {
    const isDark = document.documentElement.classList.toggle('dark');
    setDarkMode(isDark);
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
  };

  const handleExportData = () => {
    const exportData = {
      exportedAt: new Date().toISOString(),
      user: { email: user?.email },
      bodyWeight,
      exercises,
      workouts,
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sweat-buddy-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Data exported successfully!');
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    setDeleting(true);
    try {
      // Delete all user data from tables
      await supabase.from('workouts').delete().eq('user_id', user.id);
      await supabase.from('exercise_library').delete().eq('user_id', user.id);
      await supabase.from('user_settings').delete().eq('user_id', user.id);
      // Sign out — auth record deletion requires a server-side admin call;
      // data is fully wiped and the account is effectively deactivated.
      await signOut();
      toast.success('Your data has been deleted and you have been signed out.');
    } catch (err: any) {
      toast.error(err.message || 'Failed to delete account. Please try again.');
    } finally {
      setDeleting(false);
      setShowDeleteDialog(false);
    }
  };

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="mb-6">
      <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">{title}</p>
      <div className="bg-card rounded-xl overflow-hidden border border-border">{children}</div>
    </div>
  );

  const Row = ({ icon, label, onClick, destructive = false, right }: {
    icon: React.ReactNode; label: string; onClick?: () => void;
    destructive?: boolean; right?: React.ReactNode;
  }) => (
    <button
      onClick={onClick}
      className={`w-full flex items-center justify-between px-4 py-3.5 border-b border-border last:border-0 transition-colors hover:bg-muted/50 ${destructive ? 'text-destructive' : 'text-foreground'}`}
    >
      <div className="flex items-center gap-3">
        <span className={destructive ? 'text-destructive' : 'text-muted-foreground'}>{icon}</span>
        <span className="text-sm font-medium">{label}</span>
      </div>
      {right && <span className="text-muted-foreground text-sm">{right}</span>}
    </button>
  );

  return (
    <div className="min-h-screen bg-background pb-24 pt-safe">
      <div className="px-5 pt-6 max-w-lg mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <button onClick={() => navigate(-1)} className="text-muted-foreground hover:text-foreground">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-heading font-bold">Settings</h1>
        </div>

        <p className="text-muted-foreground text-sm mb-6">Signed in as <strong className="text-foreground">{user?.email}</strong></p>

        <Section title="Display">
          <Row
            icon={darkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            label={darkMode ? 'Dark Mode' : 'Light Mode'}
            onClick={toggleDarkMode}
            right={<span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">{darkMode ? 'On' : 'Off'}</span>}
          />
          <Row
            icon={<span className="text-xs font-bold w-4">⚖</span>}
            label="Weight Unit"
            onClick={() => setUnit(unit === 'lbs' ? 'kg' : 'lbs')}
            right={<span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full">{unit}</span>}
          />
        </Section>

        <Section title="Your Data">
          <Row
            icon={<Download className="w-4 h-4" />}
            label="Export All Data"
            onClick={handleExportData}
            right={<span className="text-xs text-muted-foreground">JSON</span>}
          />
        </Section>

        <Section title="Legal">
          <Link to="/privacy" className="w-full flex items-center justify-between px-4 py-3.5 border-b border-border transition-colors hover:bg-muted/50">
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">Privacy Policy</span>
            </div>
          </Link>
          <Link to="/terms" className="w-full flex items-center justify-between px-4 py-3.5 transition-colors hover:bg-muted/50">
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium">Terms of Service</span>
            </div>
          </Link>
        </Section>

        <Section title="Account">
          <Row
            icon={<LogOut className="w-4 h-4" />}
            label="Sign Out"
            onClick={signOut}
          />
          <Row
            icon={<Trash2 className="w-4 h-4" />}
            label="Delete Account & Data"
            onClick={() => setShowDeleteDialog(true)}
            destructive
          />
        </Section>

        <p className="text-center text-[11px] text-muted-foreground/50 mt-4">
          Sweat Buddy · Not a medical device
        </p>
      </div>

      {/* Delete Account Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={open => { if (!open) { setShowDeleteDialog(false); setDeleteConfirmText(''); } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Account & All Data?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all your workouts, exercises, and account data. This action <strong>cannot be undone</strong>.
              <br /><br />
              Type <strong>DELETE</strong> to confirm.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <input
            className="w-full border border-border rounded-md px-3 py-2 text-sm bg-background text-foreground mt-2"
            placeholder="Type DELETE to confirm"
            value={deleteConfirmText}
            onChange={e => setDeleteConfirmText(e.target.value)}
          />
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteConfirmText('')}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteConfirmText !== 'DELETE' || deleting}
              onClick={handleDeleteAccount}
            >
              {deleting ? 'Deleting…' : 'Delete Everything'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
