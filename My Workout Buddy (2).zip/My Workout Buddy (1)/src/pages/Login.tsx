import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dumbbell } from 'lucide-react';

type Mode = 'signin' | 'signup' | 'forgot';

export default function Login() {
  const { signIn, signUp, resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<Mode>('signin');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);
    try {
      if (mode === 'signup') {
        await signUp(email, password);
        setSuccess('Account created! Check your email to confirm your address, then sign in.');
        setMode('signin');
      } else if (mode === 'signin') {
        await signIn(email, password);
      } else {
        await resetPassword(email);
        setSuccess('Password reset link sent! Check your email.');
        setMode('signin');
      }
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const titles: Record<Mode, string> = {
    signin: 'Sign in to sync your workouts',
    signup: 'Create your account',
    forgot: 'Reset your password',
  };

  const buttonLabels: Record<Mode, string> = {
    signin: 'Sign In',
    signup: 'Create Account',
    forgot: 'Send Reset Link',
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-5">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center mx-auto mb-4">
            <Dumbbell className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-heading font-bold">Sweat Buddy</h1>
          <p className="text-muted-foreground text-sm mt-1">{titles[mode]}</p>
        </div>

        {/* Medical disclaimer — only shown on sign-up */}
        {mode === 'signup' && (
          <div className="bg-muted/50 border border-border rounded-lg p-3 mb-4 text-xs text-muted-foreground">
            <strong className="text-foreground">Health Disclaimer:</strong> Sweat Buddy is a fitness tracking tool, not a medical device. Consult a healthcare professional before starting any new exercise programme.
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            className="bg-card border-border h-12"
            required
            autoComplete="email"
          />

          {mode !== 'forgot' && (
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="bg-card border-border h-12"
              required
              minLength={6}
              autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
            />
          )}

          {error && <p className="text-destructive text-sm text-center">{error}</p>}
          {success && <p className="text-green-500 text-sm text-center">{success}</p>}

          <Button type="submit" className="w-full h-12 font-semibold" disabled={loading}>
            {loading ? 'Loading…' : buttonLabels[mode]}
          </Button>
        </form>

        {/* Mode toggles */}
        <div className="mt-4 space-y-2 text-center">
          {mode === 'signin' && (
            <>
              <button
                onClick={() => { setMode('signup'); setError(''); setSuccess(''); }}
                className="w-full text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                Don't have an account? Sign up
              </button>
              <button
                onClick={() => { setMode('forgot'); setError(''); setSuccess(''); }}
                className="w-full text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                Forgot password?
              </button>
            </>
          )}
          {(mode === 'signup' || mode === 'forgot') && (
            <button
              onClick={() => { setMode('signin'); setError(''); setSuccess(''); }}
              className="w-full text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              Already have an account? Sign in
            </button>
          )}
        </div>

        {/* Legal links */}
        <p className="text-center text-[11px] text-muted-foreground/60 mt-8">
          By continuing, you agree to our{' '}
          <Link to="/terms" className="hover:text-primary underline">Terms of Service</Link>{' '}
          and{' '}
          <Link to="/privacy" className="hover:text-primary underline">Privacy Policy</Link>.
        </p>
      </div>
    </div>
  );
}
