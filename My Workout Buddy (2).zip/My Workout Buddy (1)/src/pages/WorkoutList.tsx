import { useState } from 'react';
import { useWorkouts } from '@/hooks/useWorkouts';
import { useNavigate } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import StartWorkoutDialog from '@/components/StartWorkoutDialog';

export default function WorkoutList() {
  const { workouts } = useWorkouts();
  const navigate = useNavigate();
  const [showStart, setShowStart] = useState(false);

  const activeWorkout = workouts.find(w => !w.completed);

  return (
    <div className="min-h-screen bg-background pb-24 pt-safe">
      <div className="px-5 pt-8 max-w-lg mx-auto">
        <h1 className="text-2xl font-heading font-bold mb-6">Workout</h1>

        {activeWorkout && (
          <div
            onClick={() => navigate(`/workout/${activeWorkout.id}`)}
            className="bg-primary/10 border border-primary/30 rounded-xl p-4 mb-6 cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-primary text-xs font-semibold mb-1">IN PROGRESS</p>
                <p className="font-medium">{activeWorkout.name}</p>
                <p className="text-muted-foreground text-xs">{activeWorkout.exercises.length} exercises</p>
              </div>
              <Button size="sm" className="bg-primary text-primary-foreground">Continue</Button>
            </div>
          </div>
        )}

        <Button
          onClick={() => setShowStart(true)}
          className="w-full h-12 bg-primary text-primary-foreground hover:bg-primary/90 font-semibold rounded-xl mb-6"
        >
          <Plus className="w-5 h-5 mr-2" />
          Start Workout
        </Button>

        <h2 className="text-lg font-heading font-semibold mb-3">Completed</h2>
        <div className="space-y-2">
          {workouts.filter(w => w.completed).length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-6">No completed workouts yet</p>
          ) : (
            workouts.filter(w => w.completed).map(w => (
              <div key={w.id} className="bg-card rounded-xl p-4">
                <p className="font-medium text-sm">{w.name}</p>
                <p className="text-muted-foreground text-xs">
                  {format(new Date(w.date), 'MMM d, yyyy')} · {w.exercises.length} exercises · {w.duration}min
                </p>
              </div>
            ))
          )}
        </div>
      </div>

      <StartWorkoutDialog open={showStart} onClose={() => setShowStart(false)} />
    </div>
  );
}
