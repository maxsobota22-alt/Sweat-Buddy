import { useMemo, useState } from 'react';
import { Plus, Trash2, Dumbbell, Trophy, Pencil, Check, X } from 'lucide-react';
import { useExerciseLibrary, MUSCLE_GROUPS, MuscleGroup } from '@/hooks/useExerciseLibrary';
import { useWorkouts } from '@/hooks/useWorkouts';
import { buildExercisePRsFromWorkouts, mergeExercisePRs } from '@/lib/exercisePrs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function MyExercises() {
  const { grouped, addExercise, removeExercise, updateExerciseDetails } = useExerciseLibrary();
  const { workouts } = useWorkouts();
  const [name, setName] = useState('');
  const [muscle, setMuscle] = useState<MuscleGroup | ''>('');
  const [unilateral, setUnilateral] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editMuscle, setEditMuscle] = useState<MuscleGroup>(MUSCLE_GROUPS[0]);
  const [editUnilateral, setEditUnilateral] = useState(false);

  const handleAdd = () => {
    if (!name.trim() || !muscle) return;
    addExercise(name.trim(), muscle as MuscleGroup, unilateral);
    setName('');
    setMuscle('');
    setUnilateral(false);
  };

  const startEdit = (ex: { id: string; name: string; primaryMuscle: MuscleGroup; unilateral: boolean }) => {
    setEditingId(ex.id);
    setEditName(ex.name);
    setEditMuscle(ex.primaryMuscle);
    setEditUnilateral(ex.unilateral);
  };

  const saveEdit = () => {
    if (!editingId || !editName.trim()) return;
    updateExerciseDetails(editingId, { name: editName.trim(), primaryMuscle: editMuscle, unilateral: editUnilateral });
    setEditingId(null);
  };

  const muscleKeys = Object.keys(grouped).sort();
  const prsFromHistory = useMemo(() => buildExercisePRsFromWorkouts(workouts), [workouts]);

  return (
    <div className="min-h-screen bg-background pb-24 pt-6 px-4 max-w-lg mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <Dumbbell className="w-6 h-6 text-primary" />
        <h1 className="text-2xl font-bold text-foreground font-heading">My Exercises</h1>
      </div>

      {/* Add form */}
      <div className="bg-card rounded-xl p-4 mb-6 border border-border space-y-3">
        <p className="text-sm font-medium text-foreground">Add New Exercise</p>
        <Input
          placeholder="Exercise name"
          value={name}
          onChange={e => setName(e.target.value)}
          className="bg-secondary border-border"
        />
        <Select value={muscle} onValueChange={v => setMuscle(v as MuscleGroup)}>
          <SelectTrigger className="bg-secondary border-border">
            <SelectValue placeholder="Primary muscle group" />
          </SelectTrigger>
          <SelectContent>
            {MUSCLE_GROUPS.map(m => (
              <SelectItem key={m} value={m}>{m}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <Switch id="add-unilateral" checked={unilateral} onCheckedChange={setUnilateral} />
          <Label htmlFor="add-unilateral" className="text-sm text-muted-foreground">Unilateral (volume counts 2×)</Label>
        </div>
        <Button onClick={handleAdd} disabled={!name.trim() || !muscle} className="w-full gap-2">
          <Plus className="w-4 h-4" /> Add Exercise
        </Button>
      </div>

      {/* Exercise list by muscle */}
      {muscleKeys.length === 0 ? (
        <p className="text-muted-foreground text-center mt-12">No exercises yet. Add one above!</p>
      ) : (
        <Accordion type="multiple" defaultValue={muscleKeys} className="space-y-2">
          {muscleKeys.map(muscle => (
            <AccordionItem key={muscle} value={muscle} className="bg-card rounded-xl border border-border px-4 overflow-hidden">
              <AccordionTrigger className="text-foreground font-semibold text-sm hover:no-underline">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-primary" />
                  {muscle}
                  <span className="text-muted-foreground font-normal text-xs">({grouped[muscle].length})</span>
                </span>
              </AccordionTrigger>
              <AccordionContent>
                <ul className="space-y-3">
                  {grouped[muscle].map(ex => {
                    const displayPrs = mergeExercisePRs(ex.prs, prsFromHistory[ex.name.trim().toLowerCase()]);

                    return (
                    <li key={ex.id} className="bg-secondary rounded-lg px-3 py-2">
                      {editingId === ex.id ? (
                        <div className="space-y-2">
                          <Input
                            value={editName}
                            onChange={e => setEditName(e.target.value)}
                            className="bg-background border-border h-8 text-sm"
                          />
                          <Select value={editMuscle} onValueChange={v => setEditMuscle(v as MuscleGroup)}>
                            <SelectTrigger className="bg-background border-border h-8 text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {MUSCLE_GROUPS.map(m => (
                                <SelectItem key={m} value={m}>{m}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <div className="flex items-center gap-2">
                            <Switch id={`edit-uni-${ex.id}`} checked={editUnilateral} onCheckedChange={setEditUnilateral} />
                            <Label htmlFor={`edit-uni-${ex.id}`} className="text-xs text-muted-foreground">Unilateral</Label>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" onClick={saveEdit} className="gap-1 h-7 text-xs">
                              <Check className="w-3 h-3" /> Save
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => setEditingId(null)} className="gap-1 h-7 text-xs">
                              <X className="w-3 h-3" /> Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-foreground font-medium">{ex.name}</span>
                              {ex.unilateral && (
                                <span className="text-[10px] bg-accent text-accent-foreground px-1.5 py-0.5 rounded font-medium">UNI</span>
                              )}
                            </div>
                            <div className="flex gap-1">
                              <button onClick={() => startEdit(ex)} className="text-muted-foreground hover:text-primary transition-colors">
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button onClick={() => removeExercise(ex.id)} className="text-muted-foreground hover:text-destructive transition-colors">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          {displayPrs.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 mt-1.5">
                              {displayPrs.map(pr => (
                                <span
                                  key={`${pr.reps}-${pr.weight}`}
                                  className="inline-flex items-center gap-1 text-[10px] bg-primary/15 text-primary px-2 py-0.5 rounded-full font-medium"
                                >
                                  <Trophy className="w-2.5 h-2.5" />
                                  {pr.reps}rep × {pr.weight}lbs
                                </span>
                              ))}
                            </div>
                          )}
                        </>
                      )}
                    </li>
                  )})}
                </ul>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      )}
    </div>
  );
}
