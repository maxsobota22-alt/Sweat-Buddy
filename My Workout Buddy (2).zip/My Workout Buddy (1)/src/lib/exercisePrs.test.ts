import { describe, expect, it } from 'vitest';
import { buildExercisePRsFromWorkouts, mergeExercisePRs } from './exercisePrs';
import type { Workout } from '@/types/workout';

const workouts: Workout[] = [
  {
    id: 'w1',
    name: 'Pull',
    date: '2026-03-29T10:00:00.000Z',
    duration: 60,
    completed: true,
    exercises: [
      {
        id: 'e1',
        name: 'Deadlift',
        sets: [
          { id: 's1', reps: 5, weight: 315, completed: true },
          { id: 's2', reps: 3, weight: 335, completed: true },
        ],
      },
    ],
  },
  {
    id: 'w2',
    name: 'Pull',
    date: '2026-04-02T10:00:00.000Z',
    duration: 62,
    completed: true,
    exercises: [
      {
        id: 'e2',
        name: 'deadlift',
        sets: [
          { id: 's3', reps: 5, weight: 325, completed: true },
          { id: 's4', reps: 1, weight: 365, completed: false },
        ],
      },
    ],
  },
  {
    id: 'w3',
    name: 'Pull',
    date: '2026-04-05T10:00:00.000Z',
    duration: 58,
    completed: true,
    exercises: [
      {
        id: 'e3',
        name: 'Deadlift (barbell)',
        sets: [
          { id: 's5', reps: 4, weight: 246, completed: false },
          { id: 's6', reps: 4, weight: 245, completed: false },
          { id: 's7', reps: 3, weight: 245, completed: false },
        ],
      },
    ],
  },
];

describe('exercise PR derivation', () => {
  it('builds PRs from completed workout history', () => {
    const prsByExercise = buildExercisePRsFromWorkouts(workouts);

    expect(prsByExercise.deadlift).toEqual([
      { reps: 3, weight: 335, date: '2026-03-29T10:00:00.000Z' },
      { reps: 5, weight: 325, date: '2026-04-02T10:00:00.000Z' },
    ]);
  });

  it('uses positive sets from completed legacy workouts when set completion flags were never saved', () => {
    const prsByExercise = buildExercisePRsFromWorkouts(workouts);

    expect(prsByExercise['deadlift (barbell)']).toEqual([
      { reps: 3, weight: 245, date: '2026-04-05T10:00:00.000Z' },
      { reps: 4, weight: 246, date: '2026-04-05T10:00:00.000Z' },
    ]);
  });

  it('merges stored PRs with history-derived PRs by keeping the best value per rep count', () => {
    const merged = mergeExercisePRs(
      [{ reps: 5, weight: 315, date: '2026-03-29T10:00:00.000Z' }],
      [{ reps: 5, weight: 325, date: '2026-04-02T10:00:00.000Z' }, { reps: 3, weight: 335, date: '2026-03-29T10:00:00.000Z' }],
    );

    expect(merged).toEqual([
      { reps: 3, weight: 335, date: '2026-03-29T10:00:00.000Z' },
      { reps: 5, weight: 325, date: '2026-04-02T10:00:00.000Z' },
    ]);
  });
});
