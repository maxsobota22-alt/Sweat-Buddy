import type { ExercisePR } from '@/hooks/useExerciseLibrary';
import type { Workout } from '@/types/workout';

function normalizeExerciseName(name: string) {
  return name.trim().toLowerCase();
}

function pickBetterPR(current: ExercisePR | undefined, candidate: ExercisePR) {
  if (!current) return candidate;
  if (candidate.weight !== current.weight) {
    return candidate.weight > current.weight ? candidate : current;
  }
  return new Date(candidate.date).getTime() > new Date(current.date).getTime() ? candidate : current;
}

export function buildExercisePRsFromWorkouts(workouts: Workout[]): Record<string, ExercisePR[]> {
  const byExercise = new Map<string, Map<number, ExercisePR>>();

  workouts
    .filter(workout => workout.completed)
    .forEach(workout => {
      workout.exercises.forEach(exercise => {
        const key = normalizeExerciseName(exercise.name);
        if (!key) return;

        const prsByReps = byExercise.get(key) ?? new Map<number, ExercisePR>();
        const hasExplicitCompletedSets = exercise.sets.some(set => set.completed);

        exercise.sets.forEach(set => {
          const shouldCountSet = hasExplicitCompletedSets
            ? set.completed && set.reps > 0 && set.weight > 0
            : set.reps > 0 && set.weight > 0;

          if (!shouldCountSet) return;

          const candidate: ExercisePR = {
            reps: set.reps,
            weight: set.weight,
            date: workout.date,
          };

          prsByReps.set(set.reps, pickBetterPR(prsByReps.get(set.reps), candidate));
        });

        byExercise.set(key, prsByReps);
      });
    });

  return Object.fromEntries(
    Array.from(byExercise.entries()).map(([name, prsByReps]) => [
      name,
      Array.from(prsByReps.values()).sort((a, b) => a.reps - b.reps),
    ]),
  );
}

export function mergeExercisePRs(...sources: Array<ExercisePR[] | undefined>): ExercisePR[] {
  const merged = new Map<number, ExercisePR>();

  sources.flat().forEach(pr => {
    if (!pr) return;
    merged.set(pr.reps, pickBetterPR(merged.get(pr.reps), pr));
  });

  return Array.from(merged.values()).sort((a, b) => a.reps - b.reps);
}
