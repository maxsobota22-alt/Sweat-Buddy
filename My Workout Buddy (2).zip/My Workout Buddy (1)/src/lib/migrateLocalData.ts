import { supabase } from '@/integrations/supabase/client';
import type { Workout } from '@/types/workout';
import { DEFAULT_EXERCISES } from './defaultExercises';

interface LocalExercise {
  id: string;
  name: string;
  primaryMuscle: string;
  unilateral: boolean;
  prs: any[];
}

export async function migrateLocalDataToSupabase(userId: string) {
  try {
    // Check if user already has data in Supabase
    const { count: workoutCount } = await supabase
      .from('workouts')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId);

    const { count: exerciseCount } = await supabase
      .from('exercise_library')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId);

    if (workoutCount && workoutCount > 0) return; // Already migrated

    // Migrate workouts from localStorage
    const workoutsRaw = localStorage.getItem('workout-tracker-data');
    if (workoutsRaw) {
      const workouts: Workout[] = JSON.parse(workoutsRaw);
      if (workouts.length > 0) {
        const rows = workouts.map(w => ({
          id: w.id,
          user_id: userId,
          name: w.name,
          date: w.date,
          duration: w.duration,
          exercises: w.exercises as any,
          completed: w.completed,
        }));
        for (let i = 0; i < rows.length; i += 50) {
          await supabase.from('workouts').insert(rows.slice(i, i + 50));
        }
      }
    }

    // Migrate exercise library from localStorage
    const exercisesRaw = localStorage.getItem('exercise-library');
    if (exercisesRaw) {
      const exercises: LocalExercise[] = JSON.parse(exercisesRaw);
      if (exercises.length > 0) {
        const rows = exercises.map(e => ({
          id: e.id,
          user_id: userId,
          name: e.name,
          primary_muscle: e.primaryMuscle,
          unilateral: e.unilateral ?? false,
          prs: (e.prs || []) as any,
        }));
        await supabase.from('exercise_library').insert(rows);
        return; // Don't also seed defaults if user had their own exercises
      }
    }

    // Seed default exercise library for brand-new users with no prior data
    if (!exerciseCount || exerciseCount === 0) {
      const rows = DEFAULT_EXERCISES.map(e => ({
        id: crypto.randomUUID(),
        user_id: userId,
        name: e.name,
        primary_muscle: e.primaryMuscle,
        unilateral: e.unilateral,
        prs: [] as any,
      }));
      // Insert in batches of 50
      for (let i = 0; i < rows.length; i += 50) {
        await supabase.from('exercise_library').insert(rows.slice(i, i + 50));
      }
    }

    // Migrate body weight from localStorage
    const bwRaw = localStorage.getItem('body-weight');
    if (bwRaw) {
      const bw = Number(bwRaw);
      if (bw > 0) {
        await supabase.from('user_settings').insert({
          user_id: userId,
          body_weight: bw,
        });
      }
    }

    console.log('Initial setup complete for user');
  } catch (err) {
    console.error('Migration/setup error:', err);
  }
}
