import type { MuscleGroup } from '@/hooks/useExerciseLibrary';

export interface DefaultExercise {
  name: string;
  primaryMuscle: MuscleGroup;
  unilateral: boolean;
}

export const DEFAULT_EXERCISES: DefaultExercise[] = [
  // Chest
  { name: 'Bench Press', primaryMuscle: 'Chest', unilateral: false },
  { name: 'Incline Bench Press', primaryMuscle: 'Chest', unilateral: false },
  { name: 'Dumbbell Flyes', primaryMuscle: 'Chest', unilateral: false },
  { name: 'Push-Ups', primaryMuscle: 'Chest', unilateral: false },
  { name: 'Cable Crossover', primaryMuscle: 'Chest', unilateral: false },

  // Back
  { name: 'Pull-Ups', primaryMuscle: 'Lats', unilateral: false },
  { name: 'Lat Pulldown', primaryMuscle: 'Lats', unilateral: false },
  { name: 'Seated Cable Row', primaryMuscle: 'Upper Back', unilateral: false },
  { name: 'Barbell Row', primaryMuscle: 'Upper Back', unilateral: false },
  { name: 'Dumbbell Row', primaryMuscle: 'Lats', unilateral: true },
  { name: 'Deadlift', primaryMuscle: 'Lower Back', unilateral: false },
  { name: 'Romanian Deadlift', primaryMuscle: 'Lower Back', unilateral: false },
  { name: 'Hyperextensions', primaryMuscle: 'Lower Back', unilateral: false },
  { name: 'Face Pull', primaryMuscle: 'Rear Delts', unilateral: false },
  { name: 'Shrugs', primaryMuscle: 'Traps', unilateral: false },

  // Shoulders
  { name: 'Overhead Press', primaryMuscle: 'Front Delts', unilateral: false },
  { name: 'Dumbbell Shoulder Press', primaryMuscle: 'Front Delts', unilateral: false },
  { name: 'Lateral Raises', primaryMuscle: 'Side Delts', unilateral: false },
  { name: 'Front Raises', primaryMuscle: 'Front Delts', unilateral: false },
  { name: 'Reverse Flyes', primaryMuscle: 'Rear Delts', unilateral: false },

  // Biceps
  { name: 'Barbell Curl', primaryMuscle: 'Biceps', unilateral: false },
  { name: 'Dumbbell Curl', primaryMuscle: 'Biceps', unilateral: true },
  { name: 'Hammer Curl', primaryMuscle: 'Biceps', unilateral: true },
  { name: 'Preacher Curl', primaryMuscle: 'Biceps', unilateral: false },
  { name: 'Cable Curl', primaryMuscle: 'Biceps', unilateral: false },

  // Triceps
  { name: 'Tricep Pushdown', primaryMuscle: 'Triceps', unilateral: false },
  { name: 'Skull Crushers', primaryMuscle: 'Triceps', unilateral: false },
  { name: 'Overhead Tricep Extension', primaryMuscle: 'Triceps', unilateral: false },
  { name: 'Dips', primaryMuscle: 'Triceps', unilateral: false },
  { name: 'Close-Grip Bench Press', primaryMuscle: 'Triceps', unilateral: false },

  // Legs — Quads
  { name: 'Squat', primaryMuscle: 'Quads', unilateral: false },
  { name: 'Front Squat', primaryMuscle: 'Quads', unilateral: false },
  { name: 'Leg Press', primaryMuscle: 'Quads', unilateral: false },
  { name: 'Leg Extension', primaryMuscle: 'Quads', unilateral: false },
  { name: 'Lunges', primaryMuscle: 'Quads', unilateral: true },
  { name: 'Bulgarian Split Squat', primaryMuscle: 'Quads', unilateral: true },

  // Legs — Hamstrings & Glutes
  { name: 'Leg Curl', primaryMuscle: 'Hamstrings', unilateral: false },
  { name: 'Hip Thrust', primaryMuscle: 'Glutes', unilateral: false },
  { name: 'Glute Bridge', primaryMuscle: 'Glutes', unilateral: false },
  { name: 'Sumo Deadlift', primaryMuscle: 'Glutes', unilateral: false },

  // Calves
  { name: 'Standing Calf Raise', primaryMuscle: 'Calves', unilateral: false },
  { name: 'Seated Calf Raise', primaryMuscle: 'Calves', unilateral: false },

  // Core
  { name: 'Plank', primaryMuscle: 'Abs', unilateral: false },
  { name: 'Crunches', primaryMuscle: 'Abs', unilateral: false },
  { name: 'Cable Crunch', primaryMuscle: 'Abs', unilateral: false },
  { name: 'Leg Raises', primaryMuscle: 'Abs', unilateral: false },

  // Forearms
  { name: 'Wrist Curl', primaryMuscle: 'Forearms', unilateral: false },
];
