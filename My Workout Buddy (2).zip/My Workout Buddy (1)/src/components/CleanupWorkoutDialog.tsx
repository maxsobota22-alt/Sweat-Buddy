import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWorkouts } from '@/hooks/useWorkouts';
import { useExerciseLibrary, MUSCLE_GROUPS } from '@/hooks/useExerciseLibrary';
import { X, ChevronRight, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function CleanupWorkoutDialog({ open, onClose }: Props) {
  const { workouts, createWorkout } = useWorkouts();
  const { exercises: libraryExercises } = useExerciseLibrary();
  const navigate = useNavigate();
  const [selectedExercises, setSelectedExercises] = useState<Set<string>>(new Set());
  const [workoutCount, setWorkoutCount] = useState(5);

  const analysis = useMemo(() => {
    const completed = workouts
      .filter(w => w.completed)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, workoutCount);

    const setCounts: Record<string, number> = {};
    MUSCLE_GROUPS.forEach(m => (setCounts[m] = 0));

    completed.forEach(w => {
      w.exercises.forEach(e => {
        const muscle = e.primaryMuscle || libraryExercises.find(
          le => le.name.toLowerCase() === e.name.toLowerCase()
        )?.primaryMuscle;
        if (muscle && muscle in setCounts) {
          setCounts[muscle] += e.sets.length;
        }
      });
    });

    const entries = Object.entries(setCounts).sort((a, b) => a[1] - b[1]);
    const avg = entries.reduce((s, [, v]) => s + v, 0) / entries.length;

    return { setCounts: entries, avg, workoutsAnalyzed: completed.length };
  }, [workouts, libraryExercises, workoutCount]);

  const underworked = analysis.setCounts.filter(([, count]) => count <= analysis.avg);

  const exercisesByMuscle = useMemo(() => {
    const map: Record<string, typeof libraryExercises> = {};
    underworked.forEach(([muscle]) => {
      map[muscle] = libraryExercises.filter(
        e => e.primaryMuscle === muscle
      );
    });
    return map;
  }, [underworked, libraryExercises]);

  const toggleExercise = (name: string) => {
    setSelectedExercises(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const handleStart = () => {
    if (selectedExercises.size === 0) return;
    const exercises = Array.from(selectedExercises).map(name => ({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2),
      name,
      sets: [{ id: Date.now().toString(36) + Math.random().toString(36).slice(2), reps: 0, weight: 0, completed: false }],
    }));
    const w = createWorkout('Cleanup Workout', exercises);
    onClose();
    navigate(`/workout/${w.id}`);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-end sm:items-center justify-center">
      <div className="w-full max-w-lg bg-card rounded-t-2xl sm:rounded-2xl border border-border p-5 max-h-[85vh] overflow-y-auto animate-slide-up">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-bold text-lg flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Cleanup Workout
          </h2>
          <button onClick={onClose}>
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        <p className="text-muted-foreground text-xs mb-3">
          Based on your last {analysis.workoutsAnalyzed} workouts, these muscle groups have the fewest sets.
          Pick exercises to cover them.
        </p>

        {/* Filter */}
        <div className="flex items-center gap-2 mb-4">
          <span className="text-xs text-muted-foreground">Analyze last</span>
          {[4, 5, 6, 8].map(n => (
            <button
              key={n}
              onClick={() => setWorkoutCount(n)}
              className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                workoutCount === n
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {n}
            </button>
          ))}
          <span className="text-xs text-muted-foreground">workouts</span>
        </div>

        {underworked.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-8">
            All muscle groups are well-balanced! 💪
          </p>
        ) : (
          <div className="space-y-4">
            {underworked.map(([muscle, count]) => (
              <div key={muscle}>
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-sm font-semibold">{muscle}</p>
                  <span className="text-[11px] text-muted-foreground">
                    {count} sets (avg {Math.round(analysis.avg)})
                  </span>
                </div>
                {/* Progress bar */}
                <div className="h-1.5 bg-secondary rounded-full mb-2 overflow-hidden">
                  <div
                    className="h-full bg-primary/60 rounded-full transition-all"
                    style={{ width: `${analysis.avg > 0 ? Math.min(100, (count / analysis.avg) * 100) : 0}%` }}
                  />
                </div>
                {exercisesByMuscle[muscle]?.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {exercisesByMuscle[muscle].map(ex => (
                      <button
                        key={ex.id}
                        onClick={() => toggleExercise(ex.name)}
                        className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                          selectedExercises.has(ex.name)
                            ? 'bg-primary text-primary-foreground border-primary'
                            : 'bg-secondary text-foreground border-border hover:border-primary/50'
                        }`}
                      >
                        {selectedExercises.has(ex.name) && <Check className="w-3 h-3 inline mr-1" />}
                        {ex.name}
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-muted-foreground italic">
                    No exercises saved for this muscle group
                  </p>
                )}
              </div>
            ))}
          </div>
        )}

        {selectedExercises.size > 0 && (
          <Button onClick={handleStart} className="w-full mt-5">
            Start Cleanup ({selectedExercises.size} exercises)
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        )}
      </div>
    </div>
  );
}
