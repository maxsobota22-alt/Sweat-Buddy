import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWorkouts } from '@/hooks/useWorkouts';
import { Workout } from '@/types/workout';
import { format } from 'date-fns';
import { X, ChevronRight, Zap, History, AlertTriangle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CleanupWorkoutDialog from './CleanupWorkoutDialog';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function StartWorkoutDialog({ open, onClose }: Props) {
  const { workouts, createWorkout, addExerciseWithSets, deleteWorkout } = useWorkouts();
  const navigate = useNavigate();
  const [step, setStep] = useState<'choose' | 'previous' | 'active-warning'>('choose');
  const [showCleanup, setShowCleanup] = useState(false);

  const completedWorkouts = workouts
    .filter(w => w.completed)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const activeWorkout = workouts.find(w => !w.completed);

  // What we want to do after resolving active workout conflict
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);

  const startNewWorkout = (action: () => void) => {
    if (activeWorkout) {
      setPendingAction(() => action);
      setStep('active-warning');
    } else {
      action();
    }
  };

  const handleCustom = () => {
    startNewWorkout(() => {
      const w = createWorkout('Custom Workout');
      onClose();
      setStep('choose');
      navigate(`/workout/${w.id}`);
    });
  };

  const handleSelectPrevious = (prev: Workout) => {
    startNewWorkout(() => {
      const w = createWorkout(prev.name);
      prev.exercises.forEach(ex => {
        addExerciseWithSets(w.id, ex.name, ex.sets.map(s => ({ reps: s.reps, weight: s.weight })));
      });
      onClose();
      setStep('choose');
      navigate(`/workout/${w.id}`);
    });
  };

  const handleContinueActive = () => {
    onClose();
    setStep('choose');
    setPendingAction(null);
    if (activeWorkout) navigate(`/workout/${activeWorkout.id}`);
  };

  const handleDiscardAndProceed = () => {
    if (activeWorkout) {
      deleteWorkout(activeWorkout.id);
      localStorage.removeItem(`workout-start-${activeWorkout.id}`);
    }
    setStep('choose');
    // Run the pending action after discard
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  return (
    <>
    {open && (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-end sm:items-center justify-center">
      <div className="w-full max-w-lg bg-card rounded-t-2xl sm:rounded-2xl border border-border p-5 max-h-[80vh] overflow-y-auto animate-slide-up">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-heading font-bold text-lg">
            {step === 'choose' ? 'Start Workout' : step === 'previous' ? 'Previous Workouts' : 'Active Workout'}
          </h2>
          <button onClick={() => { onClose(); setStep('choose'); setPendingAction(null); }}>
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {step === 'active-warning' && activeWorkout && (
          <div className="space-y-4">
            <div className="flex items-start gap-3 bg-secondary rounded-xl p-4">
              <AlertTriangle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-sm">You have an active workout</p>
                <p className="text-muted-foreground text-xs mt-1">
                  "{activeWorkout.name}" is still in progress. Would you like to continue it or discard it?
                </p>
              </div>
            </div>
            <div className="space-y-2">
              <Button onClick={handleContinueActive} className="w-full" variant="default">
                Continue "{activeWorkout.name}"
              </Button>
              <Button onClick={handleDiscardAndProceed} className="w-full" variant="outline">
                Discard & Start New
              </Button>
            </div>
          </div>
        )}

        {step === 'choose' && (
          <div className="space-y-3">
            <button
              onClick={handleCustom}
              className="w-full flex items-center gap-4 bg-secondary rounded-xl p-4 hover:bg-secondary/80 transition-colors text-left"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm">Custom Workout</p>
                <p className="text-muted-foreground text-xs">Pick exercises as you go</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>

            <button
              onClick={() => setStep('previous')}
              className="w-full flex items-center gap-4 bg-secondary rounded-xl p-4 hover:bg-secondary/80 transition-colors text-left"
              disabled={completedWorkouts.length === 0}
            >
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <History className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm">Use Previous Workout</p>
                <p className="text-muted-foreground text-xs">
                  {completedWorkouts.length === 0 ? 'No completed workouts yet' : 'Repeat a recent session'}
                </p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>

            <button
              onClick={() => { onClose(); setShowCleanup(true); }}
              className="w-full flex items-center gap-4 bg-secondary rounded-xl p-4 hover:bg-secondary/80 transition-colors text-left"
              disabled={completedWorkouts.length === 0}
            >
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm">Cleanup Workout</p>
                <p className="text-muted-foreground text-xs">
                  {completedWorkouts.length === 0 ? 'No completed workouts yet' : 'Target underworked muscles'}
                </p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        )}

        {step === 'previous' && (
          <div className="space-y-2">
            <Button variant="ghost" size="sm" onClick={() => setStep('choose')} className="mb-2 text-muted-foreground">
              ← Back
            </Button>
            {completedWorkouts.length === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-8">No completed workouts</p>
            ) : (
              completedWorkouts.map(w => (
                <button
                  key={w.id}
                  onClick={() => handleSelectPrevious(w)}
                  className="w-full text-left bg-secondary rounded-xl p-4 hover:bg-secondary/80 transition-colors"
                >
                  <p className="font-medium text-sm">{w.name}</p>
                  <p className="text-muted-foreground text-xs">
                    {format(new Date(w.date), 'MMM d, yyyy')} · {w.exercises.length} exercises · {w.duration}min
                  </p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {w.exercises.map(e => (
                      <span key={e.id} className="text-[10px] bg-muted px-2 py-0.5 rounded-full text-muted-foreground">
                        {e.name}
                      </span>
                    ))}
                  </div>
                </button>
              ))
            )}
          </div>
        )}
      </div>
    </div>
    )}

    <CleanupWorkoutDialog open={showCleanup} onClose={() => setShowCleanup(false)} />
    </>
  );
}
