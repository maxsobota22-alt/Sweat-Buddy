

## Fix: Cleanup Workout "Not Found" After Starting

### Root Cause

The `CleanupWorkoutDialog.handleStart` function calls `createWorkout()` which fires a DB insert **asynchronously**, then immediately calls `addExerciseWithSets()` multiple times. Each `addExerciseWithSets` call does a `supabase.from('workouts').update(...)` — but the workout row hasn't been inserted yet (the insert is still in-flight). The update matches 0 rows and silently fails.

When the page navigates to `/workout/{id}`, the React Query cache may have the workout briefly, but any refetch hits the DB where either:
- The row doesn't exist yet, or
- It exists with empty exercises (the insert completed but the updates were lost)

Either way, the workout appears empty or missing.

### Fix

Change `CleanupWorkoutDialog.handleStart` to **build all exercises upfront** and pass them into `createWorkout`, so the workout is inserted into the DB with its exercises in a single operation. No separate `addExerciseWithSets` calls needed.

**Step 1:** Add an optional `exercises` parameter to `createWorkout` in `useWorkouts.ts` so it can accept pre-built exercises at creation time.

**Step 2:** Update `CleanupWorkoutDialog.handleStart` to build the exercise array locally and pass it to `createWorkout` in one call, instead of calling `addExerciseWithSets` in a loop.

### Changes

| File | Change |
|------|--------|
| `src/hooks/useWorkouts.ts` | Add optional `exercises` param to `createWorkout` so it inserts them with the workout row |
| `src/components/CleanupWorkoutDialog.tsx` | Build exercises array locally, pass to `createWorkout`, remove `addExerciseWithSets` loop |

