import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useWorkouts } from '@/hooks/useWorkouts';
import { useExerciseLibrary } from '@/hooks/useExerciseLibrary';
import { useBodyWeight } from '@/hooks/useBodyWeight';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, Check, ChevronLeft, X, Search, ChevronUp, ChevronDown, StickyNote } from 'lucide-react';

const TIMER_KEY_PREFIX = 'workout-start-';

export default function ActiveWorkout() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    workouts, updateWorkout, addExercise, removeExercise, reorderExercise,
    addSet, updateSet, removeSet, updateExercise,
  } = useWorkouts();
  const { exercises: libraryExercises, processPRs, getExerciseMuscle } = useExerciseLibrary();
  const { bodyWeight, resolveWeight } = useBodyWeight();

  const workout = workouts.find(w => w.id === id);
  const [showExercisePicker, setShowExercisePicker] = useState(false);
  const [exerciseSearch, setExerciseSearch] = useState('');
  const [expandedNotes, setExpandedNotes] = useState<Set<string>>(new Set());

  // Persist timer in localStorage
  const timerKey = `${TIMER_KEY_PREFIX}${id}`;
  const [startTime] = useState<number>(() => {
    const stored = localStorage.getItem(timerKey);
    if (stored) return Number(stored);
    const now = Date.now();
    localStorage.setItem(timerKey, now.toString());
    return now;
  });
  const [elapsed, setElapsed] = useState(() => Math.floor((Date.now() - startTime) / 60000));

  // Track raw weight input strings so user can type "BW + 25"
  const [weightInputs, setWeightInputs] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!workout || workout.completed) return;
    const timer = setInterval(() => setElapsed(Math.floor((Date.now() - startTime) / 60000)), 10000);
    return () => clearInterval(timer);
  }, [workout, startTime]);

  // Fix: redirect in useEffect instead of during render
  useEffect(() => {
    if (workout?.completed) {
      navigate('/history', { replace: true });
    }
  }, [workout?.completed, navigate]);

  if (!workout) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Workout not found</p>
      </div>
    );
  }

  if (workout.completed) return null;

  const toggleNotes = (exerciseId: string) => {
    setExpandedNotes(prev => {
      const next = new Set(prev);
      if (next.has(exerciseId)) next.delete(exerciseId);
      else next.add(exerciseId);
      return next;
    });
  };

  const handleFinish = () => {
    const shouldFinish = window.confirm('Are you sure you are done with the workout?');
    if (!shouldFinish) return;

    const nowIso = new Date().toISOString();
    const duration = Math.max(1, elapsed || Math.floor((Date.now() - startTime) / 60000));

    const exercisesWithMuscle = workout.exercises.map(e => ({
      ...e,
      primaryMuscle: e.primaryMuscle || getExerciseMuscle(e.name) || undefined,
      sets: e.sets.map(s => {
        const rawKey = `${e.id}-${s.id}`;
        const raw = weightInputs[rawKey];
        const resolvedWeight = raw ? resolveWeight(raw) : s.weight;
        return { ...s, weight: resolvedWeight };
      }),
    }));

    const exerciseSets = exercisesWithMuscle.map(e => ({
      name: e.name,
      sets: e.sets.filter(s => s.completed).map(s => ({ reps: s.reps, weight: s.weight })),
    }));
    processPRs(exerciseSets, nowIso);

    updateWorkout(workout.id, {
      completed: true,
      duration,
      date: nowIso,
      exercises: exercisesWithMuscle,
    });

    // Clear persisted timer
    localStorage.removeItem(timerKey);

    navigate(`/workout-report/${workout.id}`);
  };

  const handleAddExercise = (name: string) => {
    addExercise(workout.id, name);
    setShowExercisePicker(false);
    setExerciseSearch('');
  };

  const handleWeightChange = (exerciseId: string, setId: string, value: string) => {
    const key = `${exerciseId}-${setId}`;
    setWeightInputs(prev => ({ ...prev, [key]: value }));
    const num = Number(value);
    if (!isNaN(num) && value.trim() !== '') {
      updateSet(workout.id, exerciseId, setId, { weight: num });
    }
  };

  const handleWeightBlur = (exerciseId: string, setId: string) => {
    const key = `${exerciseId}-${setId}`;
    const raw = weightInputs[key];
    if (raw) {
      const resolved = resolveWeight(raw);
      updateSet(workout.id, exerciseId, setId, { weight: resolved });
    }
  };

  const getWeightDisplay = (exerciseId: string, setId: string, weight: number): string => {
    const key = `${exerciseId}-${setId}`;
    if (weightInputs[key] !== undefined) return weightInputs[key];
    return weight ? weight.toString() : '';
  };

  const filteredLibrary = libraryExercises.filter(e =>
    e.name.toLowerCase().includes(exerciseSearch.toLowerCase())
  );
  const pickerGrouped = filteredLibrary.reduce<Record<string, typeof filteredLibrary>>((acc, ex) => {
    (acc[ex.primaryMuscle] ??= []).push(ex);
    return acc;
  }, {});
  const muscleKeys = Object.keys(pickerGrouped).sort();

  return (
    <div className="min-h-screen bg-background pb-24 pt-safe">
      <div className="px-5 pt-4 max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={() => navigate('/workout')} className="text-muted-foreground">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="text-center">
            <Input
              value={workout.name}
              onChange={e => updateWorkout(workout.id, { name: e.target.value })}
              className="bg-transparent border-none text-center font-heading font-bold text-lg p-0 h-auto focus-visible:ring-0"
            />
            <p className="text-muted-foreground text-xs">{elapsed || 0} min</p>
          </div>
          <Button
            onClick={handleFinish}
            size="sm"
            className="bg-primary text-primary-foreground font-semibold"
          >
            <Check className="w-4 h-4 mr-1" />
            Finish
          </Button>
        </div>

        {bodyWeight > 0 && (
          <p className="text-muted-foreground text-xs text-center mb-4">
            BW = {bodyWeight} lbs · Type "BW" or "BW + 25" in weight fields
          </p>
        )}

        {/* Exercises */}
        <div className="space-y-4">
          {workout.exercises.map((exercise, exIdx) => (
            <div key={exercise.id} className="bg-card rounded-xl p-4 animate-slide-up">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-primary font-semibold text-sm">{exercise.name}</h3>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => toggleNotes(exercise.id)}
                    className={`p-1 transition-colors ${expandedNotes.has(exercise.id) ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
                    title="Notes"
                  >
                    <StickyNote className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => reorderExercise(workout.id, exercise.id, 'up')}
                    disabled={exIdx === 0}
                    className="text-muted-foreground hover:text-foreground disabled:opacity-30 p-1"
                  >
                    <ChevronUp className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => reorderExercise(workout.id, exercise.id, 'down')}
                    disabled={exIdx === workout.exercises.length - 1}
                    className="text-muted-foreground hover:text-foreground disabled:opacity-30 p-1"
                  >
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => removeExercise(workout.id, exercise.id)}
                    className="text-muted-foreground hover:text-destructive p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Notes */}
              {expandedNotes.has(exercise.id) && (
                <Textarea
                  placeholder="Add notes for this exercise..."
                  value={exercise.notes || ''}
                  onChange={e => updateExercise(workout.id, exercise.id, { notes: e.target.value })}
                  className="mb-3 min-h-[60px] text-xs bg-secondary border-none resize-none"
                />
              )}

              {/* Sets header */}
              <div className="grid grid-cols-[2rem_1fr_1fr_2rem] gap-2 mb-2 text-muted-foreground text-[11px] font-medium">
                <span>SET</span>
                <span>LBS</span>
                <span>REPS</span>
                <span></span>
              </div>

              {/* Sets */}
              {exercise.sets.map((set, i) => (
                <div
                  key={set.id}
                  className={`grid grid-cols-[2rem_1fr_1fr_2rem] gap-2 items-center mb-2 ${
                    set.completed ? 'opacity-60' : ''
                  }`}
                >
                  <span className="text-muted-foreground text-xs text-center">{i + 1}</span>
                  <Input
                    placeholder="0"
                    value={getWeightDisplay(exercise.id, set.id, set.weight)}
                    onChange={e => handleWeightChange(exercise.id, set.id, e.target.value)}
                    onBlur={() => handleWeightBlur(exercise.id, set.id)}
                    className="h-9 bg-secondary border-none text-center text-sm"
                  />
                  <Input
                    type="number"
                    placeholder="0"
                    value={set.reps || ''}
                    onChange={e => updateSet(workout.id, exercise.id, set.id, { reps: Number(e.target.value) })}
                    className="h-9 bg-secondary border-none text-center text-sm"
                  />
                  <button
                    onClick={() => {
                      if (set.completed) {
                        updateSet(workout.id, exercise.id, set.id, { completed: false });
                      } else if (set.reps > 0) {
                        const key = `${exercise.id}-${set.id}`;
                        const raw = weightInputs[key];
                        if (raw) {
                          const resolved = resolveWeight(raw);
                          updateSet(workout.id, exercise.id, set.id, { completed: true, weight: resolved });
                        } else {
                          updateSet(workout.id, exercise.id, set.id, { completed: true });
                        }
                      }
                    }}
                    className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors ${
                      set.completed
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              <Button
                variant="ghost"
                size="sm"
                onClick={() => addSet(workout.id, exercise.id)}
                className="w-full mt-1 text-muted-foreground hover:text-primary text-xs"
              >
                <Plus className="w-3 h-3 mr-1" />
                Add Set
              </Button>
            </div>
          ))}
        </div>

        {/* Add Exercise Button */}
        <Button
          onClick={() => setShowExercisePicker(true)}
          variant="outline"
          className="w-full mt-4 border-dashed border-muted-foreground/30 text-muted-foreground hover:text-primary hover:border-primary/30 h-12"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Exercise
        </Button>

        {/* Exercise Picker */}
        {showExercisePicker && (
          <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm pt-safe">
            <div className="px-5 pt-4 max-w-lg mx-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading font-bold text-lg">Add Exercise</h2>
                <button onClick={() => { setShowExercisePicker(false); setExerciseSearch(''); }}>
                  <X className="w-6 h-6 text-muted-foreground" />
                </button>
              </div>
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  autoFocus
                  placeholder="Search exercises..."
                  value={exerciseSearch}
                  onChange={e => setExerciseSearch(e.target.value)}
                  className="pl-10 bg-card border-border"
                />
              </div>
              <div className="space-y-4 max-h-[65vh] overflow-y-auto">
                {muscleKeys.length === 0 && (
                  <p className="text-muted-foreground text-sm text-center py-8">
                    No exercises found. Add exercises in the My Exercises tab first.
                  </p>
                )}
                {muscleKeys.map(muscle => (
                  <div key={muscle}>
                    <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">{muscle}</p>
                    <div className="space-y-1">
                      {pickerGrouped[muscle].map(ex => {
                        const prs = (ex.prs as { reps: number; weight: number; date: string }[]) || [];
                        const topPrs = [...prs].sort((a, b) => b.weight - a.weight).slice(0, 3);
                        return (
                          <button
                            key={ex.id}
                            onClick={() => handleAddExercise(ex.name)}
                            className="w-full text-left p-3 rounded-lg hover:bg-card text-sm transition-colors"
                          >
                            <span>{ex.name}</span>
                            {topPrs.length > 0 && (
                              <p className="text-[11px] text-muted-foreground mt-0.5">
                                {topPrs.map(pr => `${pr.reps}×${pr.weight}`).join(' · ')}
                              </p>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
