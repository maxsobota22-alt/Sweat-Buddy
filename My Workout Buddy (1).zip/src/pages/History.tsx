import { useWorkouts } from '@/hooks/useWorkouts';
import { useExerciseLibrary } from '@/hooks/useExerciseLibrary';
import { useAuth } from '@/hooks/useAuth';
import { format } from 'date-fns';
import { Trash2, Pencil, Heart, Upload, Loader2, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useState, useRef } from 'react';
import { toast } from 'sonner';
import type { HeartRateAnalysis } from '@/types/workout';

const intensityColors: Record<string, string> = {
  low: 'bg-green-500/20 text-green-400',
  moderate: 'bg-yellow-500/20 text-yellow-400',
  high: 'bg-orange-500/20 text-orange-400',
  very_high: 'bg-red-500/20 text-red-400',
};

const intensityLabels: Record<string, string> = {
  low: 'Low',
  moderate: 'Moderate',
  high: 'High',
  very_high: 'Very High',
};

export default function History() {
  const { workouts, deleteWorkout, updateWorkout } = useWorkouts();
  const { isUnilateral } = useExerciseLibrary();
  const { user } = useAuth();
  const navigate = useNavigate();
  const completed = workouts.filter(w => w.completed);
  const [uploadingId, setUploadingId] = useState<string | null>(null);
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);
  const [viewingHR, setViewingHR] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadTargetRef = useRef<string | null>(null);

  const handleEdit = (id: string) => {
    updateWorkout(id, { completed: false });
    navigate(`/workout/${id}`);
  };

  const handleDelete = (id: string) => {
    if (!window.confirm('Are you sure you want to delete this workout? This cannot be undone.')) return;
    deleteWorkout(id);
  };

  const handleHRClick = (workoutId: string, hasImage: boolean) => {
    if (hasImage) {
      setViewingHR(viewingHR === workoutId ? null : workoutId);
    } else {
      uploadTargetRef.current = workoutId;
      fileInputRef.current?.click();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const workoutId = uploadTargetRef.current;
    if (!file || !user || !workoutId) return;
    e.target.value = '';

    setUploadingId(workoutId);
    try {
      const filePath = `${user.id}/${workoutId}.${file.name.split('.').pop()}`;
      const { error: uploadError } = await supabase.storage
        .from('workout-images')
        .upload(filePath, file, { upsert: true });
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage.from('workout-images').getPublicUrl(filePath);
      const imageUrl = urlData.publicUrl;
      updateWorkout(workoutId, { heart_rate_image: imageUrl });

      setUploadingId(null);
      setAnalyzingId(workoutId);

      const w = workouts.find(w => w.id === workoutId);
      const workoutSummary = w ? `${w.name}, ${w.duration} min, ${w.exercises.length} exercises` : '';
      const { data: analysis, error: fnError } = await supabase.functions.invoke('analyze-heart-rate', {
        body: { imageUrl, workoutSummary },
      });
      if (fnError) throw fnError;

      updateWorkout(workoutId, { heart_rate_analysis: analysis });
      setViewingHR(workoutId);
      toast.success('Heart rate data analyzed!');
    } catch (err: any) {
      console.error('HR upload error:', err);
      toast.error(err.message || 'Failed to upload/analyze');
    } finally {
      setUploadingId(null);
      setAnalyzingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 pt-safe">
      <div className="px-5 pt-8 max-w-lg mx-auto">
        <h1 className="text-2xl font-heading font-bold mb-6">History</h1>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />

        {completed.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground">No workout history yet</p>
            <p className="text-muted-foreground text-sm mt-1">Complete a workout to see it here</p>
          </div>
        ) : (
          <div className="space-y-3">
            {completed.map(w => {
              const totalVolume = w.exercises.reduce((s, e) => {
                const mult = isUnilateral(e.name) ? 2 : 1;
                return s + e.sets.reduce((ss, set) => ss + set.reps * set.weight * mult, 0);
              }, 0);
              const hrAnalysis = w.heart_rate_analysis as HeartRateAnalysis | undefined;
              const hasHR = !!w.heart_rate_image;
              const isUploading = uploadingId === w.id;
              const isAnalyzing = analyzingId === w.id;
              const showingHR = viewingHR === w.id;

              return (
                <div key={w.id} className="bg-card rounded-xl p-4 animate-slide-up">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-semibold">{w.name}</p>
                      <p className="text-muted-foreground text-xs">
                        {format(new Date(w.date), 'EEEE, MMM d · h:mm a')}
                      </p>
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleHRClick(w.id, hasHR)}
                        className={`p-1 transition-colors ${hasHR ? 'text-red-500 hover:text-red-400' : 'text-muted-foreground hover:text-red-500'}`}
                        title={hasHR ? 'View heart rate data' : 'Add heart rate screenshot'}
                      >
                        {isUploading || isAnalyzing ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : hasHR ? (
                          <Heart className="w-4 h-4 fill-current" />
                        ) : (
                          <Heart className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        onClick={() => handleEdit(w.id)}
                        className="text-muted-foreground hover:text-primary p-1"
                        title="Edit workout"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(w.id)}
                        className="text-muted-foreground hover:text-destructive p-1"
                        title="Delete workout"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex gap-4 text-xs text-muted-foreground mb-3">
                    <span>{w.duration} min</span>
                    <span>{w.exercises.length} exercises</span>
                    <span className="text-primary font-medium">{totalVolume.toLocaleString()} lbs</span>
                    {hrAnalysis && (
                      <span className={`font-medium px-1.5 py-0.5 rounded-full text-[10px] ${intensityColors[hrAnalysis.intensity] || ''}`}>
                        {intensityLabels[hrAnalysis.intensity]} · {hrAnalysis.peak_hr} bpm
                      </span>
                    )}
                  </div>

                  <div className="space-y-1">
                    {w.exercises.map(e => (
                      <div key={e.id}>
                        <div className="flex justify-between text-xs">
                          <span className="text-foreground/80">{e.name}</span>
                          <span className="text-muted-foreground">
                            {e.sets.length} × {Math.max(...e.sets.map(s => s.weight))} lbs
                          </span>
                        </div>
                        {e.notes && (
                          <p className="text-[10px] text-muted-foreground/70 italic ml-2 mt-0.5">{e.notes}</p>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* HR Analysis expanded view */}
                  {showingHR && hrAnalysis && (
                    <div className="mt-3 pt-3 border-t border-border">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-1.5">
                          <Heart className="w-3.5 h-3.5 text-red-500" />
                          <span className="text-xs font-medium">Heart Rate</span>
                        </div>
                        <button onClick={() => setViewingHR(null)} className="text-muted-foreground hover:text-foreground">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        <div className="bg-background rounded-lg p-2 text-center">
                          <p className="text-lg font-bold text-red-500">{hrAnalysis.peak_hr}</p>
                          <p className="text-[10px] text-muted-foreground">Peak</p>
                        </div>
                        <div className="bg-background rounded-lg p-2 text-center">
                          <p className="text-lg font-bold text-primary">{hrAnalysis.avg_hr}</p>
                          <p className="text-[10px] text-muted-foreground">Avg</p>
                        </div>
                      </div>
                      {hrAnalysis.zones && hrAnalysis.zones.length > 0 && (
                        <div className="mb-2 space-y-0.5">
                          {hrAnalysis.zones.map((z, i) => (
                            <div key={i} className="flex justify-between text-[11px]">
                              <span className="text-foreground/80">{z.zone}</span>
                              <span className="text-muted-foreground">{z.minutes} min</span>
                            </div>
                          ))}
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground">{hrAnalysis.summary}</p>
                      {w.heart_rate_image && (
                        <img src={w.heart_rate_image} alt="Heart rate" className="mt-2 rounded-lg w-full max-h-40 object-contain bg-background" />
                      )}
                      <button
                        onClick={() => { uploadTargetRef.current = w.id; fileInputRef.current?.click(); }}
                        className="mt-1 text-[10px] text-muted-foreground hover:text-primary"
                      >
                        Replace screenshot
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
