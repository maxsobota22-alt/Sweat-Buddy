import { useState } from 'react';
import { useWorkouts } from '@/hooks/useWorkouts';
import { useBodyWeight } from '@/hooks/useBodyWeight';
import { useExerciseLibrary } from '@/hooks/useExerciseLibrary';
import { useNavigate } from 'react-router-dom';
import { Dumbbell, Flame, Timer, TrendingUp, Plus, Weight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { format } from 'date-fns';
import StartWorkoutDialog from '@/components/StartWorkoutDialog';

export default function Dashboard() {
  const { workouts, getStats } = useWorkouts();
  const { isUnilateral } = useExerciseLibrary();
  const { bodyWeight, updateBodyWeight } = useBodyWeight();
  const navigate = useNavigate();
  const stats = getStats(isUnilateral);
  const recentWorkouts = workouts.filter(w => w.completed).slice(0, 5);
  const [showStart, setShowStart] = useState(false);
  const [editingBW, setEditingBW] = useState(false);
  const [bwInput, setBwInput] = useState(bodyWeight.toString());

  const handleBWSave = () => {
    const val = Number(bwInput);
    if (!isNaN(val) && val > 0) updateBodyWeight(val);
    setEditingBW(false);
  };

  const calcWorkoutVolume = (w: typeof workouts[0]) =>
    w.exercises.reduce((s, e) => {
      const mult = isUnilateral(e.name) ? 2 : 1;
      return s + e.sets.reduce((ss, set) => ss + set.reps * set.weight * mult, 0);
    }, 0);

  return (
    <div className="min-h-screen bg-background pb-24 pt-safe">
      <div className="px-5 pt-8 max-w-lg mx-auto">
        {/* Header */}
        <div className="mb-8">
          <p className="text-muted-foreground text-sm font-medium mb-1">
            {format(new Date(), 'EEEE, MMM d')}
          </p>
          <h1 className="text-3xl font-heading font-bold tracking-tight">
            Let's Train 💪
          </h1>
        </div>

        {/* Quick Start */}
        <Button
          onClick={() => setShowStart(true)}
          className="w-full h-14 text-base font-semibold rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 animate-pulse-glow mb-6"
        >
          <Plus className="w-5 h-5 mr-2" />
          Start Workout
        </Button>

        {/* Body Weight */}
        <div className="bg-card rounded-xl p-4 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Weight className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Body Weight (BW)</span>
          </div>
          {editingBW ? (
            <div className="flex items-center gap-2">
              <Input
                autoFocus
                type="number"
                value={bwInput}
                onChange={e => setBwInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleBWSave()}
                className="w-20 h-8 text-center text-sm bg-secondary border-border"
              />
              <Button size="sm" variant="ghost" onClick={handleBWSave} className="h-8 text-xs text-primary">
                Save
              </Button>
            </div>
          ) : (
            <button
              onClick={() => { setBwInput(bodyWeight.toString()); setEditingBW(true); }}
              className="text-sm font-semibold text-primary hover:underline"
            >
              {bodyWeight > 0 ? `${bodyWeight} lbs` : 'Set BW'}
            </button>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          <StatCard icon={<Dumbbell className="w-4 h-4" />} label="Total Workouts" value={stats.totalWorkouts.toString()} />
          <StatCard icon={<Flame className="w-4 h-4" />} label="This Week" value={stats.thisWeek.toString()} />
          <StatCard icon={<TrendingUp className="w-4 h-4" />} label="Total Volume" value={formatVolume(stats.totalVolume)} />
          <StatCard icon={<Timer className="w-4 h-4" />} label="Total Minutes" value={stats.totalDuration.toString()} />
        </div>

        {/* Recent Workouts */}
        <div>
          <h2 className="text-lg font-heading font-semibold mb-3">Recent Workouts</h2>
          {recentWorkouts.length === 0 ? (
            <div className="bg-card rounded-xl p-6 text-center">
              <p className="text-muted-foreground text-sm">No workouts yet. Start your first one!</p>
            </div>
          ) : (
            <div className="space-y-2">
              {recentWorkouts.map(w => (
                <div key={w.id} className="bg-card rounded-xl p-4 flex items-center justify-between animate-slide-up">
                  <div>
                    <p className="font-medium text-sm">{w.name}</p>
                    <p className="text-muted-foreground text-xs">
                      {format(new Date(w.date), 'MMM d')} · {w.exercises.length} exercises · {w.duration}min
                    </p>
                  </div>
                  <div className="text-primary text-xs font-semibold">
                    {formatVolume(calcWorkoutVolume(w))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <StartWorkoutDialog open={showStart} onClose={() => setShowStart(false)} />
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-card rounded-xl p-4">
      <div className="flex items-center gap-2 text-primary mb-2">
        {icon}
        <span className="text-[11px] text-muted-foreground font-medium">{label}</span>
      </div>
      <p className="text-2xl font-heading font-bold">{value}</p>
    </div>
  );
}

function formatVolume(v: number): string {
  if (v >= 1000000) return (v / 1000000).toFixed(1) + 'M';
  if (v >= 1000) return (v / 1000).toFixed(1) + 'k';
  return v.toString();
}
