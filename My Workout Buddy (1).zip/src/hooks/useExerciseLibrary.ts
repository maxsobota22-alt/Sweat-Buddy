import { useCallback, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import type { Json } from '@/integrations/supabase/types';

export const MUSCLE_GROUPS = [
  'Calves', 'Hamstrings', 'Quads', 'Glutes', 'Abs', 'Lower Back',
  'Upper Back', 'Lats', 'Traps', 'Chest', 'Front Delts', 'Side Delts',
  'Rear Delts', 'Biceps', 'Triceps', 'Forearms',
] as const;

export type MuscleGroup = typeof MUSCLE_GROUPS[number];

export interface ExercisePR {
  reps: number;
  weight: number;
  date: string;
}

export interface LibraryExercise {
  id: string;
  name: string;
  primaryMuscle: MuscleGroup;
  unilateral: boolean;
  prs: ExercisePR[];
}

function rowToExercise(row: any): LibraryExercise {
  return {
    id: row.id,
    name: row.name,
    primaryMuscle: row.primary_muscle as MuscleGroup,
    unilateral: row.unilateral ?? false,
    prs: (row.prs as ExercisePR[]) || [],
  };
}

export function useExerciseLibrary() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const userId = user?.id;

  const { data: exercises = [] } = useQuery({
    queryKey: ['exercise-library', userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from('exercise_library')
        .select('*')
        .eq('user_id', userId)
        .order('name');
      if (error) throw error;
      return (data || []).map(rowToExercise);
    },
    enabled: !!userId,
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['exercise-library', userId] });

  const addExercise = useCallback((name: string, primaryMuscle: MuscleGroup, unilateral = false) => {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
    const newEx: LibraryExercise = { id, name, primaryMuscle, unilateral, prs: [] };
    queryClient.setQueryData<LibraryExercise[]>(['exercise-library', userId], prev => [...(prev || []), newEx]);
    supabase.from('exercise_library').insert({
      id,
      user_id: userId!,
      name,
      primary_muscle: primaryMuscle,
      unilateral,
      prs: [] as unknown as Json,
    }).then(({ error }) => { if (error) console.error(error); invalidate(); });
  }, [userId, queryClient]);

  const updateExerciseDetails = useCallback((id: string, updates: Partial<Pick<LibraryExercise, 'name' | 'primaryMuscle' | 'unilateral'>>) => {
    queryClient.setQueryData<LibraryExercise[]>(['exercise-library', userId], prev =>
      (prev || []).map(e => e.id === id ? { ...e, ...updates } : e)
    );
    const dbUpdates: any = {};
    if (updates.name !== undefined) dbUpdates.name = updates.name;
    if (updates.primaryMuscle !== undefined) dbUpdates.primary_muscle = updates.primaryMuscle;
    if (updates.unilateral !== undefined) dbUpdates.unilateral = updates.unilateral;
    supabase.from('exercise_library').update(dbUpdates).eq('id', id)
      .then(({ error }) => { if (error) console.error(error); invalidate(); });
  }, [userId, queryClient]);

  const removeExercise = useCallback((id: string) => {
    queryClient.setQueryData<LibraryExercise[]>(['exercise-library', userId], prev =>
      (prev || []).filter(e => e.id !== id)
    );
    supabase.from('exercise_library').delete().eq('id', id)
      .then(({ error }) => { if (error) console.error(error); invalidate(); });
  }, [userId, queryClient]);

  const processPRs = useCallback(async (exerciseSets: { name: string; sets: { reps: number; weight: number }[] }[], date: string) => {
    // Fetch fresh data from DB
    if (!userId) return;
    const { data } = await supabase.from('exercise_library').select('*').eq('user_id', userId);
    if (!data) return;
    const current = data.map(rowToExercise);

    const updates: { id: string; prs: ExercisePR[] }[] = [];

    exerciseSets.forEach(({ name, sets }) => {
      const ex = current.find(e => e.name.toLowerCase() === name.toLowerCase());
      if (!ex) return;
      const prs = [...ex.prs];

      sets.forEach(({ reps, weight }) => {
        if (reps <= 0 || weight <= 0) return;
        const prIdx = prs.findIndex(p => p.reps === reps);
        if (prIdx === -1) {
          prs.push({ reps, weight, date });
        } else if (weight > prs[prIdx].weight) {
          prs[prIdx] = { reps, weight, date };
        }
      });

      prs.sort((a, b) => a.reps - b.reps);
      if (JSON.stringify(prs) !== JSON.stringify(ex.prs)) {
        updates.push({ id: ex.id, prs });
      }
    });

    for (const u of updates) {
      await supabase.from('exercise_library').update({ prs: u.prs as unknown as Json }).eq('id', u.id);
    }
    invalidate();
  }, [userId, queryClient]);

  const grouped = useMemo(() =>
    exercises.reduce<Record<string, LibraryExercise[]>>((acc, ex) => {
      (acc[ex.primaryMuscle] ??= []).push(ex);
      return acc;
    }, {}),
  [exercises]);

  const getExerciseMuscle = useCallback((name: string): string | undefined => {
    return exercises.find(e => e.name.toLowerCase() === name.toLowerCase())?.primaryMuscle;
  }, [exercises]);

  const isUnilateral = useCallback((name: string): boolean => {
    return exercises.find(e => e.name.toLowerCase() === name.toLowerCase())?.unilateral ?? false;
  }, [exercises]);

  return { exercises, grouped, addExercise, updateExerciseDetails, removeExercise, processPRs, getExerciseMuscle, isUnilateral };
}
