import { useCallback, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { Workout, Exercise, WorkoutSet, ExerciseHistory, HeartRateAnalysis } from '@/types/workout';
import type { Json } from '@/integrations/supabase/types';

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function rowToWorkout(row: any): Workout {
  return {
    id: row.id,
    name: row.name,
    date: row.date,
    duration: row.duration,
    exercises: (row.exercises as any[]) || [],
    completed: row.completed,
    heart_rate_image: row.heart_rate_image ?? undefined,
    heart_rate_analysis: row.heart_rate_analysis as HeartRateAnalysis | undefined,
  };
}

export function useWorkouts() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const userId = user?.id;

  const { data: workouts = [] } = useQuery({
    queryKey: ['workouts', userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from('workouts')
        .select('*')
        .eq('user_id', userId)
        .order('date', { ascending: false });
      if (error) throw error;
      return (data || []).map(rowToWorkout);
    },
    enabled: !!userId,
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['workouts', userId] });

  const createWorkout = useCallback((name: string, initialExercises?: Exercise[]): Workout => {
    const workout: Workout = {
      id: generateId(),
      name,
      date: new Date().toISOString(),
      duration: 0,
      exercises: initialExercises || [],
      completed: false,
    };
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev => [workout, ...(prev || [])]);
    supabase.from('workouts').insert({
      id: workout.id,
      user_id: userId!,
      name: workout.name,
      date: workout.date,
      duration: workout.duration,
      exercises: workout.exercises as unknown as Json,
      completed: workout.completed,
    }).then(({ error }) => { if (error) console.error('createWorkout error:', error); });
    return workout;
  }, [userId, queryClient]);

  const updateWorkout = useCallback((id: string, updates: Partial<Workout>) => {
    // Optimistic update
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w => w.id === id ? { ...w, ...updates } : w)
    );
    const dbUpdates: any = {};
    if (updates.name !== undefined) dbUpdates.name = updates.name;
    if (updates.date !== undefined) dbUpdates.date = updates.date;
    if (updates.duration !== undefined) dbUpdates.duration = updates.duration;
    if (updates.exercises !== undefined) dbUpdates.exercises = updates.exercises as unknown as Json;
    if (updates.completed !== undefined) dbUpdates.completed = updates.completed;
    if (updates.heart_rate_image !== undefined) dbUpdates.heart_rate_image = updates.heart_rate_image;
    if (updates.heart_rate_analysis !== undefined) dbUpdates.heart_rate_analysis = updates.heart_rate_analysis as unknown as Json;
    supabase.from('workouts').update(dbUpdates).eq('id', id).then(({ error }) => {
      if (error) console.error('updateWorkout error:', error);
      invalidate();
    });
  }, [userId, queryClient]);

  const deleteWorkout = useCallback((id: string) => {
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).filter(w => w.id !== id)
    );
    supabase.from('workouts').delete().eq('id', id).then(({ error }) => {
      if (error) console.error('deleteWorkout error:', error);
      invalidate();
    });
  }, [userId, queryClient]);

  const addExercise = useCallback((workoutId: string, name: string) => {
    const exercise: Exercise = {
      id: generateId(),
      name,
      sets: [{ id: generateId(), reps: 0, weight: 0, completed: false }],
    };
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w =>
        w.id === workoutId ? { ...w, exercises: [...w.exercises, exercise] } : w
      )
    );
    // Persist full exercises array
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('addExercise error:', error); });
    }
  }, [userId, queryClient]);

  const addExerciseWithSets = useCallback((workoutId: string, name: string, templateSets: { reps: number; weight: number }[]) => {
    const sets: WorkoutSet[] = templateSets.map(s => ({
      id: generateId(), reps: s.reps, weight: s.weight, completed: false,
    }));
    const exercise: Exercise = {
      id: generateId(),
      name,
      sets: sets.length > 0 ? sets : [{ id: generateId(), reps: 0, weight: 0, completed: false }],
    };
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w =>
        w.id === workoutId ? { ...w, exercises: [...w.exercises, exercise] } : w
      )
    );
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('addExerciseWithSets error:', error); });
    }
  }, [userId, queryClient]);

  const updateExercise = useCallback((workoutId: string, exerciseId: string, updates: Partial<Exercise>) => {
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w =>
        w.id === workoutId
          ? { ...w, exercises: w.exercises.map(e => e.id === exerciseId ? { ...e, ...updates } : e) }
          : w
      )
    );
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('updateExercise error:', error); });
    }
  }, [userId, queryClient]);

  const removeExercise = useCallback((workoutId: string, exerciseId: string) => {
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w =>
        w.id === workoutId ? { ...w, exercises: w.exercises.filter(e => e.id !== exerciseId) } : w
      )
    );
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('removeExercise error:', error); });
    }
  }, [userId, queryClient]);

  const reorderExercise = useCallback((workoutId: string, exerciseId: string, direction: 'up' | 'down') => {
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w => {
        if (w.id !== workoutId) return w;
        const exercises = [...w.exercises];
        const idx = exercises.findIndex(e => e.id === exerciseId);
        if (idx === -1) return w;
        const newIdx = direction === 'up' ? idx - 1 : idx + 1;
        if (newIdx < 0 || newIdx >= exercises.length) return w;
        [exercises[idx], exercises[newIdx]] = [exercises[newIdx], exercises[idx]];
        return { ...w, exercises };
      })
    );
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('reorderExercise error:', error); });
    }
  }, [userId, queryClient]);

  const addSet = useCallback((workoutId: string, exerciseId: string) => {
    const newSet: WorkoutSet = { id: generateId(), reps: 0, weight: 0, completed: false };
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w =>
        w.id === workoutId
          ? { ...w, exercises: w.exercises.map(e => e.id === exerciseId ? { ...e, sets: [...e.sets, newSet] } : e) }
          : w
      )
    );
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('addSet error:', error); });
    }
  }, [userId, queryClient]);

  const updateSet = useCallback((workoutId: string, exerciseId: string, setId: string, updates: Partial<WorkoutSet>) => {
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w =>
        w.id === workoutId
          ? {
              ...w,
              exercises: w.exercises.map(e =>
                e.id === exerciseId
                  ? { ...e, sets: e.sets.map(s => s.id === setId ? { ...s, ...updates } : s) }
                  : e
              ),
            }
          : w
      )
    );
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('updateSet error:', error); });
    }
  }, [userId, queryClient]);

  const removeSet = useCallback((workoutId: string, exerciseId: string, setId: string) => {
    queryClient.setQueryData<Workout[]>(['workouts', userId], prev =>
      (prev || []).map(w =>
        w.id === workoutId
          ? {
              ...w,
              exercises: w.exercises.map(e =>
                e.id === exerciseId
                  ? { ...e, sets: e.sets.filter(s => s.id !== setId) }
                  : e
              ),
            }
          : w
      )
    );
    const updated = queryClient.getQueryData<Workout[]>(['workouts', userId])?.find(w => w.id === workoutId);
    if (updated) {
      supabase.from('workouts').update({ exercises: updated.exercises as unknown as Json }).eq('id', workoutId)
        .then(({ error }) => { if (error) console.error('removeSet error:', error); });
    }
  }, [userId, queryClient]);

  const getExerciseHistory = useCallback((exerciseName: string): ExerciseHistory[] => {
    const history: ExerciseHistory[] = [];
    workouts
      .filter(w => w.completed)
      .forEach(w => {
        w.exercises
          .filter(e => e.name.toLowerCase() === exerciseName.toLowerCase())
          .forEach(e => {
            const totalVolume = e.sets.reduce((sum, s) => sum + s.reps * s.weight, 0);
            const maxWeight = Math.max(...e.sets.map(s => s.weight), 0);
            const totalReps = e.sets.reduce((sum, s) => sum + s.reps, 0);
            history.push({ date: w.date, maxWeight, totalVolume, totalSets: e.sets.length, totalReps });
          });
      });
    return history.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [workouts]);

  const getUniqueExercises = useCallback((): string[] => {
    const names = new Set<string>();
    workouts.forEach(w => w.exercises.forEach(e => names.add(e.name)));
    return Array.from(names).sort();
  }, [workouts]);

  const getStats = useCallback((isUnilateral?: (name: string) => boolean) => {
    const completed = workouts.filter(w => w.completed);
    const totalWorkouts = completed.length;
    const totalVolume = completed.reduce((sum, w) =>
      sum + w.exercises.reduce((eSum, e) => {
        const mult = isUnilateral?.(e.name) ? 2 : 1;
        return eSum + e.sets.reduce((sSum, s) => sSum + s.reps * s.weight * mult, 0);
      }, 0), 0);
    const totalDuration = completed.reduce((sum, w) => sum + w.duration, 0);
    const thisWeek = completed.filter(w => {
      const d = new Date(w.date);
      const now = new Date();
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      return d >= weekAgo;
    }).length;
    return { totalWorkouts, totalVolume, totalDuration, thisWeek };
  }, [workouts]);

  return {
    workouts,
    createWorkout,
    updateWorkout,
    deleteWorkout,
    addExercise,
    addExerciseWithSets,
    updateExercise,
    removeExercise,
    reorderExercise,
    addSet,
    updateSet,
    removeSet,
    getExerciseHistory,
    getUniqueExercises,
    getStats,
  };
}
