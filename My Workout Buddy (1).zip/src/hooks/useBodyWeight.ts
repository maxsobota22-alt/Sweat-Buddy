import { useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export function useBodyWeight() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const userId = user?.id;

  const { data: bodyWeight = 0 } = useQuery({
    queryKey: ['body-weight', userId],
    queryFn: async () => {
      if (!userId) return 0;
      const { data, error } = await supabase
        .from('user_settings')
        .select('body_weight')
        .eq('user_id', userId)
        .maybeSingle();
      if (error) throw error;
      return data?.body_weight ?? 0;
    },
    enabled: !!userId,
  });

  const updateBodyWeight = useCallback((weight: number) => {
    queryClient.setQueryData(['body-weight', userId], weight);
    if (!userId) return;
    supabase.from('user_settings').upsert(
      { user_id: userId, body_weight: weight, updated_at: new Date().toISOString() },
      { onConflict: 'user_id' }
    ).then(({ error }) => {
      if (error) console.error('updateBodyWeight error:', error);
      queryClient.invalidateQueries({ queryKey: ['body-weight', userId] });
    });
  }, [userId, queryClient]);

  const resolveWeight = useCallback((input: string): number => {
    const trimmed = input.trim().toUpperCase();
    if (trimmed === 'BW') return bodyWeight;
    const bwMatch = trimmed.match(/^BW\s*\+\s*(\d+(?:\.\d+)?)$/);
    if (bwMatch) return bodyWeight + Number(bwMatch[1]);
    const bwMinusMatch = trimmed.match(/^BW\s*-\s*(\d+(?:\.\d+)?)$/);
    if (bwMinusMatch) return Math.max(0, bodyWeight - Number(bwMinusMatch[1]));
    const num = Number(input);
    return isNaN(num) ? 0 : num;
  }, [bodyWeight]);

  return { bodyWeight, updateBodyWeight, resolveWeight };
}
