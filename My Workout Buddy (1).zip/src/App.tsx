import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { migrateLocalDataToSupabase } from "@/lib/migrateLocalData";
import { useEffect, useRef } from "react";
import BottomNav from "@/components/BottomNav";
import Dashboard from "./pages/Dashboard";
import WorkoutList from "./pages/WorkoutList";
import ActiveWorkout from "./pages/ActiveWorkout";
import WorkoutReport from "./pages/WorkoutReport";
import History from "./pages/History";
import Progress from "./pages/Progress";
import MyExercises from "./pages/MyExercises";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";

const queryClient = new QueryClient();

function AuthGate() {
  const { user, loading } = useAuth();
  const migrated = useRef(false);

  useEffect(() => {
    if (user && !migrated.current) {
      migrated.current = true;
      migrateLocalDataToSupabase(user.id);
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return <Login />;

  return (
    <>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/workout" element={<WorkoutList />} />
        <Route path="/workout/:id" element={<ActiveWorkout />} />
        <Route path="/workout-report/:id" element={<WorkoutReport />} />
        <Route path="/history" element={<History />} />
        <Route path="/progress" element={<Progress />} />
        <Route path="/exercises" element={<MyExercises />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <BottomNav />
    </>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthGate />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
